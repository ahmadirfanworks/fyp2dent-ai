<?php
session_start();

$role = strtolower($_SESSION['role'] ?? '');
$backPage = 'index.php'; // default public

if ($role === 'patient') $backPage = 'patient.php';
if ($role === 'dentist') $backPage = 'dentist.php';
if ($role === 'admin')   $backPage = 'admindashboard.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dent AI | About Us</title>
  <link rel="stylesheet" href="assets/css/style.css"/>
</head>

<body>
  <div class="container">
    <!-- Nav (Back | Brand | Menu) -->
    <nav class="nav nav-three">
      <a href="<?= $backPage ?>" class="back"><span class="arrow">←</span> Back</a>
      <a href="index.html" class="brand"><span class="logo">🦷</span> DENT AI</a>
      <ul class="menu">
        <li><a href="index.php">HOME</a></li>
        <li><a href="aboutus.php" class="active">ABOUT US</a></li>
        <li><a href="contact.php">CONTACT</a></li>
        
      </ul>
    </nav>

    <!-- About wrapper -->
    <section class="about-wrap">
      <!-- hero -->
      <header class="about-hero">
        <div>
          <h1>About Dent AI</h1>
          <p class="lead">
            Dent AI is a web platform that assists dentists in analyzing dental X-ray images,
            documenting findings, and producing structured diagnosis reports for patients.
            It streamlines clinical workflows and improves communication between dentists and patients.
          </p>
        </div>
        <div class="about-stats">
          <div class="stat">
            <span class="num">3</span>
            <span class="label">Core Modules</span>
          </div>
          <div class="stat">
            <span class="num">2</span>
            <span class="label">User Roles</span>
          </div>
          <div class="stat">
            <span class="num">∞</span>
            <span class="label">Case Records</span>
          </div>
        </div>
      </header>

      <!-- objectives + who we help -->
      <div class="about-grid">
        <article class="about-card">
          <h2>Project Objectives</h2>
          <ul class="ticks">
            <li>Provide a simple upload tool for dental X-rays with instant preview.</li>
            <li>Support AI-assisted diagnosis (future backend) with editable results for dentists.</li>
            <li>Generate consistent, readable reports for patients and clinical records.</li>
            <li>Offer history tracking to review past diagnoses and prescriptions.</li>
            <li>Establish role-based access: <strong>Dentist</strong> (analyze, save) and <strong>Patient</strong> (view reports).</li>
          </ul>
        </article>

        <article class="about-card">
          <h2>Who We Help</h2>
          <ul class="ticks">
            <li><strong>Dentists:</strong> Faster charting, structured notes, and clear patient communication.</li>
            <li><strong>Patients:</strong> Understand diagnosis and prescriptions with a friendly report view.</li>
            <li><strong>Clinics:</strong> A foundation for paperless records and future integration with EMR systems.</li>
          </ul>
        </article>
      </div>

      <!-- features -->
      <section class="about-features">
        <h2>Main Features</h2>
        <div class="feature-grid">
          <div class="feature">
            <h3>Analyze Tool</h3>
            <p>Upload X-ray images, preview instantly, and proceed to editable diagnosis and consultation notes.</p>
          </div>
          <div class="feature">
            <h3>Diagnosis Result</h3>
            <p>Editable findings, patient name entry, and prescription/consultation section. Save for history.</p>
          </div>
          <div class="feature">
            <h3>History & Reports</h3>
            <p>Search patient history and display past X-rays, diagnosis results, dates, and consultation notes.</p>
          </div>
          <div class="feature">
            <h3>Role-Based Navigation</h3>
            <p>Separate experiences for Dentist and Patient; future sessions via PHP for secure access.</p>
          </div>
        </div>
      </section>

      

      <!-- privacy -->
      <section class="about-privacy">
        <h2>Data & Privacy</h2>
        <ul class="ticks">
          <li>Patient data is handled with consent and intended for clinical use only.</li>
          <li>Future backend will implement authentication, authorization, and encrypted storage.</li>
          <li>AI output is an assistive tool; final clinical decisions remain with certified dentists.</li>
        </ul>
      </section>

      <!-- CTA -->
      <div class="about-cta">
        <a class="cta" href="login.php">Try the Demo</a>
        <a class="cta secondary" href="contact.php">Contact Team</a>
      </div>
    </section>
  </div>
</body>
</html>
