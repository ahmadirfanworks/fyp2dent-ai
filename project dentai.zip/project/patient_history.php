<?php
require 'db.php';
header('Content-Type: application/json');

$patientId = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;
if ($patientId <= 0) {
  echo json_encode(['error' => 'Invalid patient']);
  exit;
}

// 1. Get patient info
$stmt = $pdo->prepare("
  SELECT patient_id, full_name, email, date_of_birth, contact_number
  FROM patients
  WHERE patient_id = ?
  LIMIT 1
");
$stmt->execute([$patientId]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
  echo json_encode(['error' => 'Patient not found']);
  exit;
}

// 2. Get diagnosis history (CAN BE EMPTY)
$stmt = $pdo->prepare("
  SELECT report_id, diagnosis_date, diagnosis_result, created_at
  FROM diagnosis_reports
  WHERE patient_id = ?
  ORDER BY created_at DESC
");
$stmt->execute([$patientId]);
$history = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 3. Return clean JSON (NO WARNINGS)
echo json_encode([
  'patient' => $patient,
  'history' => $history
]);
