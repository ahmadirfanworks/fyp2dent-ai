<?php
session_start();
require 'db.php';

/**
 * update_prescription.php
 * Fail update nota klinikal atau preskripsi doktor bagi laporan tertentu.
 */

// 1. Kawalan Keselamatan: Pastikan hanya doktor yang log masuk boleh simpan nota
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'dentist') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 2. Ambil data daripada borang (Sanitize input)
    $reportId = (int)($_POST['report_id'] ?? 0);
    $prescription = trim($_POST['prescription'] ?? '');

    if ($reportId > 0) {
        try {
            // 3. Kemaskini ruangan prescription dalam table diagnosis_reports
            $stmt = $pdo->prepare("UPDATE diagnosis_reports SET prescription = ? WHERE report_id = ?");
            $stmt->execute([$prescription, $reportId]);

            // 4. Redirect kembali ke halaman keputusan dengan mesej berjaya (opsional)
            header("Location: diagnosis_result.php?report_id=" . $reportId . "&update=success");
            exit;
        } catch (PDOException $e) {
            // Jika ada ralat database
            die("Error updating record: " . $e->getMessage());
        }
    } else {
        die("Invalid Report ID.");
    }
} else {
    // Jika fail diakses secara terus tanpa POST
    header("Location: dentist.php");
    exit;
}