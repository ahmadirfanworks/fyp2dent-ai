<?php
session_start();
require 'db.php';

header('Content-Type: application/json');

// Admin guard
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'Forbidden']);
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
  exit;
}

$role = strtolower(trim($_POST['role'] ?? ''));
$id   = (int)($_POST['id'] ?? 0);

$full_name = trim($_POST['full_name'] ?? '');
$email     = trim($_POST['email'] ?? '');

if (!$id || !in_array($role, ['patient','dentist'], true)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid role/id']);
  exit;
}

if ($full_name === '' || $email === '') {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Full name & email required']);
  exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid email format']);
  exit;
}

// Map table/PK
if ($role === 'patient') {
  $table = 'patients';
  $pk = 'patient_id';
} else {
  $table = 'dentists';
  $pk = 'dentist_id';
}

try {
  // (Optional) prevent duplicate email within same table
  $dup = $pdo->prepare("SELECT 1 FROM $table WHERE email = ? AND $pk <> ? LIMIT 1");
  $dup->execute([$email, $id]);
  if ($dup->fetchColumn()) {
    http_response_code(409);
    echo json_encode(['ok' => false, 'error' => 'Email already exists']);
    exit;
  }

  $stmt = $pdo->prepare("UPDATE $table SET full_name = ?, email = ? WHERE $pk = ? LIMIT 1");
  $stmt->execute([$full_name, $email, $id]);

  echo json_encode(['ok' => true]);
} catch (PDOException $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
