<?php
session_start();
require 'db.php';

header('Content-Type: application/json');

// Admin guard
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'Forbidden']);
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
  exit;
}

$role = strtolower(trim($_POST['role'] ?? ''));
$id   = (int)($_POST['id'] ?? 0);

if (!$id || !in_array($role, ['patient','dentist'], true)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid role/id']);
  exit;
}

try {
  $pdo->beginTransaction();

  if ($role === 'patient') {
    // delete dependent records first (if no FK cascade)
    // diagnosis_reports usually links to patient_id
    $pdo->prepare("DELETE FROM diagnosis_reports WHERE patient_id = ?")->execute([$id]);
    // xray_images usually links to patient_id
    $pdo->prepare("DELETE FROM xray_images WHERE patient_id = ?")->execute([$id]);

    $stmt = $pdo->prepare("DELETE FROM patients WHERE patient_id = ? LIMIT 1");
    $stmt->execute([$id]);

  } else { // dentist
    // diagnosis_reports may link to dentist_id
    $pdo->prepare("DELETE FROM diagnosis_reports WHERE dentist_id = ?")->execute([$id]);

    $stmt = $pdo->prepare("DELETE FROM dentists WHERE dentist_id = ? LIMIT 1");
    $stmt->execute([$id]);
  }

  $pdo->commit();
  echo json_encode(['ok' => true]);

} catch (PDOException $e) {
  $pdo->rollBack();
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
