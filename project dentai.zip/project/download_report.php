<?php
session_start();
require 'db.php';
require 'vendor/autoload.php';

use Dompdf\Dompdf;

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'patient') {
  exit("Unauthorized");
}

$patientProfileId = (int)$_SESSION['patient_profile_id'];
$year = (int)($_GET['year'] ?? 0);
if ($year <= 0) exit("Invalid year");

// Fetch reports
$stmt = $pdo->prepare("
  SELECT dr.*, d.full_name AS dentist_name
  FROM diagnosis_reports dr
  JOIN dentists d ON dr.dentist_id = d.dentist_id
  WHERE dr.patient_profile_id = ?
  AND YEAR(dr.diagnosis_date) = ?
  ORDER BY dr.diagnosis_date ASC
");
$stmt->execute([$patientProfileId, $year]);
$reports = $stmt->fetchAll();

if (!$reports) exit("No report found");

// ===== Build PDF HTML =====
$html = "<h1>Dent AI – Dental Diagnosis Report ($year)</h1>";
$html .= "<p>Patient ID: $patientProfileId</p>";

foreach ($reports as $r) {
  $html .= "
    <hr>
    <p><strong>Date:</strong> {$r['diagnosis_date']}</p>
    <p><strong>Dentist:</strong> {$r['dentist_name']}</p>
    <p><strong>Diagnosis:</strong><br>{$r['diagnosis_result']}</p>
    <p><strong>Prescription:</strong><br>{$r['prescription']}</p>
  ";
}

// ===== Generate PDF =====
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// ===== Save to server =====
$dir = __DIR__ . "/uploads/reports/";
if (!is_dir($dir)) mkdir($dir, 0777, true);

$filename = "patient_{$patientProfileId}_{$year}.pdf";
$filepath = $dir . $filename;

file_put_contents($filepath, $dompdf->output());

// ===== Update DB (save path once per year batch) =====
$upd = $pdo->prepare("
  UPDATE diagnosis_reports
  SET pdf_path = ?
  WHERE patient_profile_id = ?
  AND YEAR(diagnosis_date) = ?
");
$upd->execute(["uploads/reports/$filename", $patientProfileId, $year]);

// ===== Force download =====
$dompdf->stream($filename, ["Attachment" => true]);
exit;
