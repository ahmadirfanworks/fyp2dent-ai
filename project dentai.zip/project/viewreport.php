<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'patient') {
  header("Location: login.php");
  exit;
}

$patientProfileId = (int)$_SESSION['patient_profile_id'];
$year = (int)($_GET['year'] ?? 0);
if ($year <= 0) die("Invalid year.");

$stmt = $pdo->prepare("
  SELECT dr.*, d.full_name AS dentist_name
  FROM diagnosis_reports dr
  JOIN dentists d ON dr.dentist_id = d.dentist_id
  WHERE dr.patient_profile_id = ?
  AND YEAR(dr.diagnosis_date) = ?
  ORDER BY dr.diagnosis_date DESC
");
$stmt->execute([$patientProfileId, $year]);
$reports = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dent AI | Diagnosis Report</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
  <h1>Diagnosis Report - <?= $year ?></h1>

  <?php foreach ($reports as $r): ?>
    <div class="report-card">
      <p><strong>Date:</strong> <?= $r['diagnosis_date'] ?></p>
      <p><strong>Dentist:</strong> <?= htmlspecialchars($r['dentist_name']) ?></p>
      <p><strong>Diagnosis:</strong><br><?= nl2br(htmlspecialchars($r['diagnosis_result'])) ?></p>
      <p><strong>Prescription:</strong><br><?= nl2br(htmlspecialchars($r['prescription'])) ?></p>
    </div>
  <?php endforeach; ?>

  <a class="action-btn" href="download_report.php?year=<?= $year ?>">
    Download PDF
  </a>
</div>
</body>
</html>
