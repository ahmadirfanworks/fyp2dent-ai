<?php
session_start();
require 'db.php';

// Guard: hanya patient boleh masuk
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'patient') {
  header("Location: login.php");
  exit;
}

$patientId = (int)$_SESSION['user_id'];

// Get patient info
$stmt = $pdo->prepare("SELECT * FROM patients WHERE patient_id = ? LIMIT 1");
$stmt->execute([$patientId]);
$p = $stmt->fetch();

if (!$p) {
  die("Patient record not found.");
}

$fullName = $p['full_name'] ?? 'Full Name';
$dob      = $p['date_of_birth'] ?? '';
$contact  = $p['contact_number'] ?? '';
$pid      = $p['patient_id'] ?? '';

$email    = $p['email'] ?? '-'; 
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dent AI — Patient Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    /* Tambahan inline style untuk dashboard layout */
    .patient-page .grid {
      display: grid;
      grid-template-columns: 1fr 1.5fr;
      gap: 25px;
      margin-top: 30px;
    }
    .profile-card {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
    }
    .btn-history {
      display: block;
      text-align: center;
      background: var(--accent, #71ec71);
      color: #0d3c0d;
      padding: 15px;
      border-radius: 50px;
      text-decoration: none;
      font-weight: 800;
      margin-top: 20px;
      transition: 0.3s;
    }
    .btn-history:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.2);
    }
    .kv .label {
      opacity: 0.7;
      font-size: 12px;
      text-transform: uppercase;
    }
    .kv .value {
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 15px;
    }
  </style>
</head>
<body class="patient-page">
  <div class="container">

    <nav class="nav">
      <a class="brand" href="patient.php">
        <span class="logo">🦷</span> DENT AI
      </a>
      <ul class="menu">
        <li><a href="patient.php" class="active">DASHBOARD</a></li>
        <li><a href="aboutus.php">ABOUT US</a></li>
        <li><a href="profile.php">PROFILE</a></li>
        <li><a href="logout.php" style="color:#ff5f5f">LOGOUT</a></li>
      </ul>
    </nav>

    <section class="grid">

      <article class="card round profile-card">
        <div class="profile-header" style="text-align:center; margin-bottom: 25px;">
          <div class="avatar" style="font-size: 50px; margin-bottom:10px;">👤</div>
          <h2 style="margin:0"><?php echo htmlspecialchars($fullName); ?></h2>
          <div style="color:rgba(255,255,255,0.7)">Patient ID: #<?php echo htmlspecialchars((string)$pid); ?></div>
        </div>

        <h3 class="section-title" style="border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px; margin-bottom: 20px;">General Info</h3>
        
        <div class="kv">
            <div class="label">Date of Birth</div>
            <div class="value"><?php echo htmlspecialchars($dob ?: '-'); ?></div>
        </div>

        <div class="kv">
            <div class="label">Contact Number</div>
            <div class="value"><?php echo htmlspecialchars($contact ?: '-'); ?></div>
        </div>

        <div class="kv">
            <div class="label">Email</div>
            <div class="value"><?php echo htmlspecialchars($email); ?></div>
        </div>

        <a class="btn-history" href="patient_viewhistory.php">VIEW DIAGNOSIS HISTORY</a>
      </article>

      <div class="right-col">
        <article class="card" style="margin-bottom:20px; background: rgba(0,0,0,0.2); border:none;">
            <h2 style="margin-bottom:10px;">Welcome back, <?php echo htmlspecialchars(explode(' ', trim($fullName))[0]); ?>!</h2>
            <p style="opacity:0.8;">Your oral health is our priority. Track your progress and view your AI-powered diagnosis reports anytime.</p>
        </article>
        
        <article class="card" style="padding:0; overflow:hidden; border:none;">
          <img class="hero-img" src="assets/img/patientanalytic.png" alt="Analytics" style="width:100%; display:block;">
        </article>
      </div>

    </section>
  </div>
</body>
</html>