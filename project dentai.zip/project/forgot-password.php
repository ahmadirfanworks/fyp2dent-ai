<?php
require 'db.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');

  if ($email === '') {
    $error = "Email is required.";
  } else {
    // check in all user tables
    $tables = [
      'patients' => 'email',
      'dentists' => 'email',
      'admins'   => 'email'
    ];

    $found = false;

    foreach ($tables as $table => $col) {
      $stmt = $pdo->prepare("SELECT 1 FROM $table WHERE $col = ? LIMIT 1");
      $stmt->execute([$email]);
      if ($stmt->fetch()) {
        $found = true;
        break;
      }
    }

    if ($found) {
      $message = "If this email exists, a password reset link has been sent.";
    } else {
      $error = "Email not found.";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dent AI | Forgot Password</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="forgot-page">
  <div class="container">

    <!-- 🌿 Navigation -->
    <nav class="nav nav-three">
      <!-- Left: Back -->
      <a href="login.php" class="back">
        <span class="arrow">←</span> Back
      </a>

      <!-- Center: Brand -->
      <a href="index.php" class="brand">
        <span class="logo">🦷</span> DENT AI
      </a>

      <!-- Right: Menu -->
      <ul class="menu">
        <li><a href="index.php">HOME</a></li>
        <li><a href="aboutus.php">ABOUT US</a></li>
        <li><a href="contact.php">CONTACT</a></li>
      </ul>
    </nav>

    <!-- 🔐 Forgot Password Layout -->
    <section class="forgot-layout">
      <div class="forgot-card">
        <h1>Forgot Your Password?</h1>
        <p class="subtext">Enter your email below and we’ll send you a reset link to get back into your account.</p>
<?php if ($message): ?>
  <p style="color:#22c55e;font-weight:600;margin-bottom:10px;">
    <?= htmlspecialchars($message) ?>
  </p>
<?php endif; ?>

<?php if ($error): ?>
  <p style="color:#ff6b6b;font-weight:600;margin-bottom:10px;">
    <?= htmlspecialchars($error) ?>
  </p>
<?php endif; ?>

        <form action="forgot-password.php" method="POST" class="forgot-form">
          <label>
            <span class="icon">📧</span>
            <input type="email" name="email" placeholder="Enter your registered email" required>
          </label>

          <button type="submit" class="btn-login">Send Reset Link</button>
        </form>

        <div class="divider">OR</div>

        <a href="login.php" class="btn-signup">Back to Login</a>
      </div>
    </section>

  </div>
</body>
</html>
