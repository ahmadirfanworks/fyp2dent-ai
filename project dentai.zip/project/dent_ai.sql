-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2026 at 07:53 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dent_ai`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `email`, `password_hash`, `created_at`) VALUES
(1, 'systemadmin', 'admin@dentai.com', 'admin123', '2025-12-15 16:39:57');

-- --------------------------------------------------------

--
-- Table structure for table `dentists`
--

CREATE TABLE `dentists` (
  `dentist_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `upload_image` varchar(255) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dentists`
--

INSERT INTO `dentists` (`dentist_id`, `username`, `full_name`, `email`, `contact_number`, `upload_image`, `password_hash`, `created_at`) VALUES
(1, 'adamfutsal', 'Adam Fitry', 'adamfutsal@gmail.com', '0124042850', NULL, '$2y$10$J9LjftCNaDjLhJB41YZ7uOAiMMGp4tK9w1uPGkJZAffAPEttPl5Fu', '2025-12-14 17:31:30'),
(2, 'hafiy', 'hafiy darwis', 'hafiy@uniten.com', '01110981896', NULL, '$2y$10$nly0/pudfjuDWHeCmhI4I.3uD5qnx5.4.5z4vHyVCpLuFYVg3eNIG', '2025-12-15 18:23:42'),
(3, 'ahmadirfan6aloe', 'ahmad irfan', 'ahmadirfan6aloe@gmail.com', '0162771235', NULL, '$2y$10$ladexlNWiUW1u3W5nq7ae.A8yIM8t7j9PYC8ZI1tB0a8f8/kBekzy', '2026-01-19 02:03:20');

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis_reports`
--

CREATE TABLE `diagnosis_reports` (
  `report_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `dentist_id` int(11) NOT NULL,
  `xray_id` int(11) DEFAULT NULL,
  `diagnosis_date` date NOT NULL,
  `diagnosis_result` text DEFAULT NULL,
  `prescription` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `pdf_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diagnosis_reports`
--

INSERT INTO `diagnosis_reports` (`report_id`, `patient_id`, `dentist_id`, `xray_id`, `diagnosis_date`, `diagnosis_result`, `prescription`, `created_at`, `pdf_path`) VALUES
(1, 1, 1, 4, '2026-01-18', 'AI analysis failed. Manual review required.', NULL, '2026-01-18 14:28:50', NULL),
(2, 1, 1, 5, '2026-01-18', 'AI analysis failed. Manual review required.', NULL, '2026-01-18 14:36:21', NULL),
(3, 1, 1, 6, '2026-01-18', 'AI analysis failed. Manual review required.', NULL, '2026-01-18 14:41:47', NULL),
(4, 1, 1, 7, '2026-01-18', 'AI analysis failed. Manual review required.', NULL, '2026-01-18 14:44:38', NULL),
(5, 1, 1, 8, '2026-01-18', 'Moderate findings detected: Caries, Impacted teeth. Schedule dental appointment for evaluation.', 'gigi yang sihat', '2026-01-18 14:51:50', NULL),
(6, 2, 1, 9, '2026-01-18', 'AI analysis failed. Manual review required.', NULL, '2026-01-18 15:18:47', NULL),
(7, 2, 1, 10, '2026-01-18', 'Moderate findings detected: Caries, Healthy Teeth. Schedule dental appointment for evaluation.', 'baek ni', '2026-01-18 15:19:57', NULL),
(8, 5, 1, 11, '2026-01-19', 'AI analysis failed. Manual review required.', NULL, '2026-01-18 16:56:33', NULL),
(9, 5, 1, 12, '2026-01-19', 'AI analysis failed. Manual review required.', NULL, '2026-01-18 16:58:39', NULL),
(10, 5, 1, 13, '2026-01-19', 'Moderate findings detected: Infection, Healthy Teeth. Schedule dental appointment for evaluation.', NULL, '2026-01-18 17:02:37', NULL),
(11, 5, 1, 14, '2026-01-19', 'Moderate findings detected: Healthy Teeth, Caries. Schedule dental appointment for evaluation.', NULL, '2026-01-18 17:04:21', NULL),
(12, 3, 1, 15, '2026-01-19', 'Moderate findings detected: Caries, BDC-BDR. Schedule dental appointment for evaluation.', NULL, '2026-01-18 17:05:30', NULL),
(13, 1, 1, 16, '2026-01-19', 'Moderate findings detected: Healthy Teeth, Caries. Schedule dental appointment for evaluation.', 'broken root', '2026-01-18 17:14:03', NULL),
(14, 3, 1, 17, '2026-01-19', 'Moderate findings detected: Healthy Teeth, Caries. Schedule dental appointment for evaluation.', NULL, '2026-01-19 00:59:41', NULL),
(15, 1, 3, 18, '2026-01-19', 'AI analysis failed. Manual review required.', NULL, '2026-01-19 02:08:40', NULL),
(16, 1, 3, 19, '2026-01-19', 'Moderate findings detected: Infection, Healthy Teeth. Schedule dental appointment for evaluation.', 'broken root', '2026-01-19 02:11:01', NULL),
(17, 1, 1, 20, '2026-01-20', 'AI analysis failed. Manual review required.', NULL, '2026-01-20 07:02:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patient_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `date_of_birth` date NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `username`, `full_name`, `email`, `date_of_birth`, `contact_number`, `password_hash`, `created_at`) VALUES
(1, 'haikal24', 'Haikal harun', 'haikal24@uniten.com', '2002-09-30', '0178724748', '$2y$10$fjpT.k9y3K7jUICx8/.XIuVEAsxuVM/iWRRd/6KElPe.l3wduNx6W', '2025-12-14 17:21:03'),
(2, 'haikal2432', 'Haikal Jerantuts', 'haikal2432@uniten.com', '2002-09-30', '0178724748', '$2y$10$uqX/95tp1iTj5rklMcvzieLrFEM8odHV399PWzkXtXIxp0yGtF51i', '2025-12-14 17:21:29'),
(3, 'afiq', 'muhammad afiq', 'afiq@uniten.com', '2003-11-12', '0134343298', '$2y$10$jGk9oyGqHQW.v0nssuBMzuqh.c6r7I47KPxktb3kI/D8JZRNrXaxq', '2025-12-16 01:58:23'),
(5, '', 'Ali abu', 'aliabufriends@gmail.com', '2026-01-15', '0178887277', '', '2026-01-18 15:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `xray_images`
--

CREATE TABLE `xray_images` (
  `xray_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `dentist_id` int(11) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `annotated_file_path` varchar(255) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ai_status` enum('PENDING','PROCESSING','DONE','FAILED') DEFAULT 'PENDING',
  `ai_raw_result` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ai_raw_result`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `xray_images`
--

INSERT INTO `xray_images` (`xray_id`, `patient_id`, `dentist_id`, `file_path`, `annotated_file_path`, `uploaded_at`, `ai_status`, `ai_raw_result`) VALUES
(4, 1, 1, 'uploads/xrays/xray_1768746470_2c537551.jpg', NULL, '2026-01-18 14:28:50', 'FAILED', '{\"error\":\"API error or invalid response code: 0\"}'),
(5, 1, 1, 'uploads/xrays/xray_1768746980_a06003e2.jpg', NULL, '2026-01-18 14:36:21', 'FAILED', '{\"error\":\"API error or invalid response code: 400\"}'),
(6, 1, 1, 'uploads/xrays/xray_1768747305_f984e84c.jpg', NULL, '2026-01-18 14:41:47', 'FAILED', '{\"error\":\"API error or invalid response code: 400\"}'),
(7, 1, 1, 'uploads/xrays/xray_1768747476_758bd0a3.jpg', NULL, '2026-01-18 14:44:38', 'FAILED', '{\"error\":\"HTTP Error Code: 400\"}'),
(8, 1, 1, 'uploads/xrays/xray_1768747904.jpg', NULL, '2026-01-18 14:51:50', '', '{\"diagnoses\":[{\"condition\":\"Caries\",\"confidence\":0.46900686621665955,\"severity\":\"Low\",\"description\":\"Caries detected with 46.9% confidence.\"},{\"condition\":\"Impacted teeth\",\"confidence\":0.424643874168396,\"severity\":\"Low\",\"description\":\"Impacted teeth detected with 42.5% confidence.\"},{\"condition\":\"BDC-BDR\",\"confidence\":0.39188551902770996,\"severity\":\"Low\",\"description\":\"BDC-BDR detected with 39.2% confidence.\"},{\"condition\":\"Healthy Teeth\",\"confidence\":0.3912670314311981,\"severity\":\"Low\",\"description\":\"Healthy Teeth detected with 39.1% confidence.\"}],\"summary\":\"Moderate findings detected: Caries, Impacted teeth. Schedule dental appointment for evaluation.\",\"recommendations\":[\"Continue regular dental check-ups every 6 months\",\"Maintain good oral hygiene practices\",\"This is an AI-assisted diagnosis. Always consult a licensed dentist.\"],\"timestamp\":\"2026-01-18T14:51:50.863207\",\"model_version\":\"1.0.0\"}'),
(9, 2, 1, 'uploads/xrays/xray_1768749437.jpg', NULL, '2026-01-18 15:18:47', 'FAILED', '{\"error\":\"HTTP 0: Operation timed out after 90007 milliseconds with 0 bytes received\"}'),
(10, 2, 1, 'uploads/xrays/xray_1768749585.jpg', NULL, '2026-01-18 15:19:57', '', '{\"diagnoses\":[{\"condition\":\"Caries\",\"confidence\":0.49950486421585083,\"severity\":\"Low\",\"description\":\"Caries detected with 50.0% confidence.\"},{\"condition\":\"Healthy Teeth\",\"confidence\":0.43698281049728394,\"severity\":\"Low\",\"description\":\"Healthy Teeth detected with 43.7% confidence.\"},{\"condition\":\"BDC-BDR\",\"confidence\":0.33947622776031494,\"severity\":\"Low\",\"description\":\"BDC-BDR detected with 33.9% confidence.\"}],\"summary\":\"Moderate findings detected: Caries, Healthy Teeth. Schedule dental appointment for evaluation.\",\"recommendations\":[\"Continue regular dental check-ups every 6 months\",\"Maintain good oral hygiene practices\",\"This is an AI-assisted diagnosis. Always consult a licensed dentist.\"],\"timestamp\":\"2026-01-18T15:19:57.170132\",\"model_version\":\"1.0.0\"}'),
(11, 5, 1, 'uploads/xrays/xray_1768755303.jpg', NULL, '2026-01-18 16:56:33', 'FAILED', '{\"error\":\"HTTP 0: Operation timed out after 90002 milliseconds with 0 bytes received\"}'),
(12, 5, 1, 'uploads/xrays/xray_1768755429.jpg', NULL, '2026-01-18 16:58:39', 'FAILED', '{\"error\":\"HTTP 0: Operation timed out after 90007 milliseconds with 0 bytes received\"}'),
(13, 5, 1, 'uploads/xrays/xray_1768755748.jpg', NULL, '2026-01-18 17:02:37', '', '{\"diagnoses\":[{\"condition\":\"Infection\",\"confidence\":0.5497184991836548,\"severity\":\"Moderate\",\"description\":\"Infection detected with 55.0% confidence.\"},{\"condition\":\"Healthy Teeth\",\"confidence\":0.4883955717086792,\"severity\":\"Low\",\"description\":\"Healthy Teeth detected with 48.8% confidence.\"},{\"condition\":\"BDC-BDR\",\"confidence\":0.32515597343444824,\"severity\":\"Low\",\"description\":\"BDC-BDR detected with 32.5% confidence.\"}],\"summary\":\"Moderate findings detected: Infection, Healthy Teeth. Schedule dental appointment for evaluation.\",\"recommendations\":[\"Continue regular dental check-ups every 6 months\",\"Maintain good oral hygiene practices\",\"This is an AI-assisted diagnosis. Always consult a licensed dentist.\"],\"timestamp\":\"2026-01-18T17:02:37.260210\",\"model_version\":\"1.0.0\"}'),
(14, 5, 1, 'uploads/xrays/xray_1768755854.jpg', NULL, '2026-01-18 17:04:21', '', '{\"diagnoses\":[{\"condition\":\"Healthy Teeth\",\"confidence\":0.6012265086174011,\"severity\":\"Moderate\",\"description\":\"Healthy Teeth detected with 60.1% confidence.\"},{\"condition\":\"Caries\",\"confidence\":0.40705040097236633,\"severity\":\"Low\",\"description\":\"Caries detected with 40.7% confidence.\"}],\"summary\":\"Moderate findings detected: Healthy Teeth, Caries. Schedule dental appointment for evaluation.\",\"recommendations\":[\"Continue regular dental check-ups every 6 months\",\"Maintain good oral hygiene practices\",\"This is an AI-assisted diagnosis. Always consult a licensed dentist.\"],\"timestamp\":\"2026-01-18T17:04:20.981388\",\"model_version\":\"1.0.0\"}'),
(15, 3, 1, 'uploads/xrays/xray_1768755924.jpg', NULL, '2026-01-18 17:05:30', '', '{\"diagnoses\":[{\"condition\":\"Caries\",\"confidence\":0.47606295347213745,\"severity\":\"Low\",\"description\":\"Caries detected with 47.6% confidence.\"},{\"condition\":\"BDC-BDR\",\"confidence\":0.3987053632736206,\"severity\":\"Low\",\"description\":\"BDC-BDR detected with 39.9% confidence.\"},{\"condition\":\"Healthy Teeth\",\"confidence\":0.3783215284347534,\"severity\":\"Low\",\"description\":\"Healthy Teeth detected with 37.8% confidence.\"}],\"summary\":\"Moderate findings detected: Caries, BDC-BDR. Schedule dental appointment for evaluation.\",\"recommendations\":[\"Continue regular dental check-ups every 6 months\",\"Maintain good oral hygiene practices\",\"This is an AI-assisted diagnosis. Always consult a licensed dentist.\"],\"timestamp\":\"2026-01-18T17:05:30.881425\",\"model_version\":\"1.0.0\"}'),
(16, 1, 1, 'uploads/xrays/xray_1768756436.jpg', NULL, '2026-01-18 17:14:03', '', '{\"diagnoses\":[{\"condition\":\"Healthy Teeth\",\"confidence\":0.6241687536239624,\"severity\":\"Moderate\",\"description\":\"Healthy Teeth detected with 62.4% confidence.\"},{\"condition\":\"Caries\",\"confidence\":0.40386682748794556,\"severity\":\"Low\",\"description\":\"Caries detected with 40.4% confidence.\"}],\"summary\":\"Moderate findings detected: Healthy Teeth, Caries. Schedule dental appointment for evaluation.\",\"recommendations\":[\"Continue regular dental check-ups every 6 months\",\"Maintain good oral hygiene practices\",\"This is an AI-assisted diagnosis. Always consult a licensed dentist.\"],\"timestamp\":\"2026-01-18T17:14:03.280467\",\"model_version\":\"1.0.0\"}'),
(17, 3, 1, 'uploads/xrays/xray_1768784372.jpg', NULL, '2026-01-19 00:59:41', '', '{\"diagnoses\":[{\"condition\":\"Healthy Teeth\",\"confidence\":0.6012265086174011,\"severity\":\"Moderate\",\"description\":\"Healthy Teeth detected with 60.1% confidence.\"},{\"condition\":\"Caries\",\"confidence\":0.40705040097236633,\"severity\":\"Low\",\"description\":\"Caries detected with 40.7% confidence.\"}],\"summary\":\"Moderate findings detected: Healthy Teeth, Caries. Schedule dental appointment for evaluation.\",\"recommendations\":[\"Continue regular dental check-ups every 6 months\",\"Maintain good oral hygiene practices\",\"This is an AI-assisted diagnosis. Always consult a licensed dentist.\"],\"timestamp\":\"2026-01-19T00:59:41.780259\",\"model_version\":\"1.0.0\"}'),
(18, 1, 3, 'uploads/xrays/xray_1768788430.jpg', NULL, '2026-01-19 02:08:40', 'FAILED', '{\"error\":\"HTTP 0: Operation timed out after 90006 milliseconds with 0 bytes received\"}'),
(19, 1, 3, 'uploads/xrays/xray_1768788617.jpg', NULL, '2026-01-19 02:11:01', '', '{\"diagnoses\":[{\"condition\":\"Infection\",\"confidence\":0.5497184991836548,\"severity\":\"Moderate\",\"description\":\"Infection detected with 55.0% confidence.\"},{\"condition\":\"Healthy Teeth\",\"confidence\":0.4883955717086792,\"severity\":\"Low\",\"description\":\"Healthy Teeth detected with 48.8% confidence.\"},{\"condition\":\"BDC-BDR\",\"confidence\":0.32515597343444824,\"severity\":\"Low\",\"description\":\"BDC-BDR detected with 32.5% confidence.\"}],\"summary\":\"Moderate findings detected: Infection, Healthy Teeth. Schedule dental appointment for evaluation.\",\"recommendations\":[\"Continue regular dental check-ups every 6 months\",\"Maintain good oral hygiene practices\",\"This is an AI-assisted diagnosis. Always consult a licensed dentist.\"],\"timestamp\":\"2026-01-19T02:11:01.602857\",\"model_version\":\"1.0.0\"}'),
(20, 1, 1, 'uploads/xrays/xray_1768892451.jpg', NULL, '2026-01-20 07:02:21', 'FAILED', '{\"error\":\"HTTP 0: Operation timed out after 90002 milliseconds with 0 bytes received\"}');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `dentists`
--
ALTER TABLE `dentists`
  ADD PRIMARY KEY (`dentist_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `diagnosis_reports`
--
ALTER TABLE `diagnosis_reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `idx_reports_date` (`diagnosis_date`),
  ADD KEY `idx_reports_patient` (`patient_id`),
  ADD KEY `idx_reports_dentist` (`dentist_id`),
  ADD KEY `fk_report_xray` (`xray_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `xray_images`
--
ALTER TABLE `xray_images`
  ADD PRIMARY KEY (`xray_id`),
  ADD KEY `idx_xray_patient` (`patient_id`),
  ADD KEY `idx_xray_dentist` (`dentist_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dentists`
--
ALTER TABLE `dentists`
  MODIFY `dentist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `diagnosis_reports`
--
ALTER TABLE `diagnosis_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `xray_images`
--
ALTER TABLE `xray_images`
  MODIFY `xray_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `diagnosis_reports`
--
ALTER TABLE `diagnosis_reports`
  ADD CONSTRAINT `fk_report_dentist` FOREIGN KEY (`dentist_id`) REFERENCES `dentists` (`dentist_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_report_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_report_xray` FOREIGN KEY (`xray_id`) REFERENCES `xray_images` (`xray_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `xray_images`
--
ALTER TABLE `xray_images`
  ADD CONSTRAINT `fk_xray_dentist` FOREIGN KEY (`dentist_id`) REFERENCES `dentists` (`dentist_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_xray_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
