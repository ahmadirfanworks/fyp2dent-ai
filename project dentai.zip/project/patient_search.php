<?php
require 'db.php';
header('Content-Type: application/json');

$q = trim($_GET['q'] ?? '');
if (strlen($q) < 2) {
  echo json_encode([]);
  exit;
}

$stmt = $pdo->prepare("
  SELECT patient_id, full_name, email, date_of_birth, contact_number
  FROM patients
  WHERE full_name LIKE ? OR email LIKE ?
  ORDER BY full_name
  LIMIT 10
");
$like = "%$q%";
$stmt->execute([$like, $like]);

echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
