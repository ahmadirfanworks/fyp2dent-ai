<?php
// download_history.php
// Export a patient's diagnosis history as CSV (dentist only)

session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'dentist') {
  header('Location: login.php');
  exit;
}

$patientProfileId = isset($_GET['patient_profile_id']) ? (int)$_GET['patient_profile_id'] : 0;
if ($patientProfileId <= 0) {
  http_response_code(400);
  echo 'Missing patient_profile_id';
  exit;
}

// Get patient
$stmtP = $pdo->prepare("SELECT patient_profile_id, full_name, email FROM patient_profiles WHERE patient_profile_id = ? LIMIT 1");
$stmtP->execute([$patientProfileId]);
$patient = $stmtP->fetch(PDO::FETCH_ASSOC);
if (!$patient) {
  http_response_code(404);
  echo 'Patient not found';
  exit;
}

// Get reports
$stmt = $pdo->prepare("
  SELECT
    dr.report_id,
    dr.diagnosis_date,
    dr.diagnosis_result,
    dr.prescription,
    dr.created_at,
    xi.file_path
  FROM diagnosis_reports dr
  LEFT JOIN xray_images xi ON xi.xray_id = dr.xray_id
  WHERE dr.patient_profile_id = ?
  ORDER BY dr.diagnosis_date DESC, dr.report_id DESC
");
$stmt->execute([$patientProfileId]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$filename = 'diagnosis_history_' . preg_replace('/[^a-zA-Z0-9_-]+/', '_', $patient['full_name'] ?? 'patient') . '_' . date('Ymd_His') . '.csv';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=' . $filename);

$out = fopen('php://output', 'w');
fputcsv($out, ['Report ID', 'Diagnosis Date', 'Diagnosis Result', 'Prescription', 'Created At', 'X-ray File Path']);
foreach ($rows as $r) {
  fputcsv($out, [
    $r['report_id'],
    $r['diagnosis_date'],
    $r['diagnosis_result'],
    $r['prescription'],
    $r['created_at'],
    $r['file_path'],
  ]);
}
fclose($out);
exit;
