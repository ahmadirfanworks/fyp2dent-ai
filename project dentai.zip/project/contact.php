<?php
session_start();

$role = strtolower($_SESSION['role'] ?? '');
$backPage = 'index.php';

if ($role === 'patient') $backPage = 'patient.php';
if ($role === 'dentist') $backPage = 'dentist.php';
if ($role === 'admin')   $backPage = 'admindashboard.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dent AI | Contact Us</title>
  <link rel="stylesheet" href="assets/css/style.css"/>
</head>

<body>
  <div class="container">
    <nav class="nav nav-three">
      <a href="<?= $backPage ?>" class="back"><span class="arrow">←</span> Back</a>
      <a href="index.php" class="brand"><span class="logo">🦷</span> DENT AI</a>
      <ul class="menu">
        <li><a href="index.php">HOME</a></li>
        <li><a href="aboutus.php">ABOUT US</a></li>
        <li><a href="contact.php" class="active">CONTACT</a></li>
      </ul>
    </nav>

    <section class="about-wrap">
      <h1>Contact Dent AI Team</h1>
      <p>
        Have questions or feedback ? Reach out to the project developer or supervisor below.
      </p>

      <div style="margin-top:20px;">
        <h2>Project Developer</h2>
        <p><strong>Name:</strong> Ahmad Irfan Kamarul Ariffin</p>
        <p><strong>Email:</strong> ahmadirfanworks@gmail.com</p>
        <p><strong>Institution:</strong> Universiti Tenaga Nasional (UNITEN)</p>
      </div>

      

      <div style="margin-top:24px;">
        <h2>Connect</h2>
        <p>Whatsapp: <a href="https://wa.me/60162721235">wa.me/60162721235</a></p>
      </div>
    </section>
  </div>
</body>
</html>
