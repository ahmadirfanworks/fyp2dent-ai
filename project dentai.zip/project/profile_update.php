<?php
session_start();
require 'db.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
  http_response_code(401);
  echo json_encode(['ok'=>false,'error'=>'Not logged in']);
  exit;
}

$userId = (int)$_SESSION['user_id'];
$role   = strtolower($_SESSION['role']);

if ($role === 'admin') {
  http_response_code(403);
  echo json_encode(['ok'=>false,'error'=>'Admin profile not supported']);
  exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$full = trim($input['full_name'] ?? '');
$contact = trim($input['contact_number'] ?? '');
$dob = trim($input['date_of_birth'] ?? '');

if ($full === '' || $contact === '') {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'Full name and contact number are required']);
  exit;
}

try {
  if ($role === 'patient') {
    $stmt = $pdo->prepare("UPDATE patients SET full_name=?, contact_number=?, date_of_birth=? WHERE patient_id=? LIMIT 1");
    $stmt->execute([$full, $contact, $dob, $userId]);
  } else { // dentist
    $stmt = $pdo->prepare("UPDATE dentists SET full_name=?, contact_number=? WHERE dentist_id=? LIMIT 1");
    $stmt->execute([$full, $contact, $userId]);
  }

  echo json_encode(['ok'=>true]);
} catch (PDOException $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
