<?php
session_start();
require 'db.php';

// Guard: user must login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
  header("Location: login.php");
  exit;
}

$userId = (int)$_SESSION['user_id'];
$role   = strtolower($_SESSION['role']);

// Role-based back destination
$backPage = 'index.html'; // fallback

if ($role === 'patient') {
  $backPage = 'patient.php';
} elseif ($role === 'dentist') {
  $backPage = 'dentist.php';
}


$success = '';
$error   = '';

// map table ikut role
if ($role === 'admin') {
  $table = 'admins';   $pk = 'admin_id';
} elseif ($role === 'dentist') {
  $table = 'dentists'; $pk = 'dentist_id';
} else {
  $table = 'patients'; $pk = 'patient_id';
}

// Change Password (real)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'change_password') {
  $curr = trim($_POST['currPw'] ?? '');
  $p1   = trim($_POST['newPw'] ?? '');
  $p2   = trim($_POST['newPw2'] ?? '');

  if ($curr === '' || $p1 === '' || $p2 === '') {
    $error = "Please fill all fields.";
  } elseif ($p1 !== $p2) {
    $error = "New password and confirmation do not match.";
  } elseif (strlen($p1) < 6) {
    $error = "Password must be at least 6 characters.";
  } else {
    $stmt = $pdo->prepare("SELECT password_hash FROM $table WHERE $pk = ? LIMIT 1");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();

    if (!$row || !password_verify($curr, $row['password_hash'])) {
      $error = "Current password is incorrect.";
    } else {
      $newHash = password_hash($p1, PASSWORD_DEFAULT);
      $up = $pdo->prepare("UPDATE $table SET password_hash = ? WHERE $pk = ? LIMIT 1");
      $up->execute([$newHash, $userId]);
      $success = "Password updated successfully ✅";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dent AI | Settings</title>
  <link rel="stylesheet" href="assets/css/style.css"/>
</head>

<body>
  <div class="container">
    <!-- NAV -->
    <nav class="nav nav-three">
      <a href="<?= $backPage ?>" class="back"><span class="arrow">←</span> Back</a>
      <a href="index.php" class="brand"><span class="logo">🦷</span> DENT AI</a>
      <ul class="menu">
        <li><a href="index.php">HOME</a></li>
        <li><a href="aboutus.php">ABOUT US</a></li>
        <li><a href="contact.php">CONTACT</a></li>
        <li><a href="settings.php" class="active">SETTINGS</a></li>
      </ul>
    </nav>

    <!-- SETTINGS WRAP -->
    <section class="settings-wrap">
      <header class="settings-head">
        <h1>Settings</h1>
        <div class="logged-pill">
          <span id="rolePill"><?= htmlspecialchars(strtoupper($role)) ?></span>
          <span class="avatar-lg">👤</span>
        </div>
      </header>

      <div class="settings-grid">
        <!-- LEFT COLUMN -->
        <div class="settings-col">
          <!-- Account Settings -->
          <div class="settings-card">
            <h2 class="settings-title">Account Settings</h2>

            <?php if ($error): ?>
              <p style="color:#ff6b6b;font-weight:700;margin:10px 0;"><?= htmlspecialchars($error) ?></p>
            <?php endif; ?>
            <?php if ($success): ?>
              <p style="color:#22c55e;font-weight:700;margin:10px 0;"><?= htmlspecialchars($success) ?></p>
            <?php endif; ?>

            <!-- ✅ keep UI, just add method/action + name fields -->
            <form id="passwordForm" class="field-stack" autocomplete="off" method="POST" action="settings.php">
              <input type="hidden" name="action" value="change_password"/>

              <div class="field">
                <label>Current Password</label>
                <input type="password" id="currPw" name="currPw" placeholder="Enter current password" required />
              </div>
              <div class="field">
                <label>New Password</label>
                <input type="password" id="newPw" name="newPw" placeholder="Enter new password" required />
              </div>
              <div class="field">
                <label>Confirm New Password</label>
                <input type="password" id="newPw2" name="newPw2" placeholder="Re-enter new password" required />
              </div>
              <div class="btn-row">
                <button type="submit" class="btn-primary">Change Password</button>
              </div>
            </form>

            <hr class="divider-line"/>

            <div class="stack danger">
              <h3 class="subttl">Delete Account</h3>
              <button id="deleteBtn" class="btn-danger">Delete Account</button>
            </div>
          </div>
        </div>

        <!-- RIGHT COLUMN -->
        <div class="settings-col">
          <!-- Notification -->
          <div class="settings-card">
            <h2 class="settings-title">Notifications</h2>
            <div class="toggle-row">
              <span class="toggle-label">Enable Notifications</span>
              <label class="switch">
                <input type="checkbox" id="notifToggle" checked />
                <span class="slider"></span>
              </label>
            </div>
          </div>

          <!-- Support & Contact -->
          <div class="settings-card">
            <h2 class="settings-title">Support & Contact</h2>
            <div class="stack">
              <p>Need help or want to report a bug? Reach out to the Dent AI team.</p>
              <div class="btn-row left">
                <a href="contact.php" class="btn-outline no-underline">Contact Page</a>
                <a href="https://wa.me/60162721235" target="_blank" class="btn-primary no-underline">WhatsApp Us</a>
              </div>
              <p class="muted">By using this system you agree to our data and privacy practices in the About page.</p>
            </div>
          </div>

          <!-- Logout -->
          <div class="settings-card">
            <h2 class="settings-title">Logout</h2>
            <button id="logoutBtn" class="btn-outline">Log Out</button>
          </div>
        </div>
      </div>
    </section>
  </div>

  <script>
    // ✅ Logout (real)
    document.getElementById('logoutBtn').addEventListener('click', ()=>{
      window.location.href = 'logout.php';
    });

    // Notification toggle (keep demo if you want)
    const notifToggle = document.getElementById('notifToggle');
    notifToggle.addEventListener('change', () => {
      const state = notifToggle.checked ? 'on' : 'off';
      localStorage.setItem('notifications', state);
    });

    // ✅ Delete Account (real)
    document.getElementById('deleteBtn').addEventListener('click', async ()=>{
      if (!confirm('Are you sure you want to delete this account? This cannot be undone.')) return;

      const res = await fetch('delete_account.php', { method:'POST' });
      const json = await res.json().catch(()=>({}));
      if (!res.ok || !json.ok) return alert(json.error || 'Delete failed');

      alert('Account deleted ✅');
      window.location.href = 'logout.php';
    });
  </script>
</body>
</html>
