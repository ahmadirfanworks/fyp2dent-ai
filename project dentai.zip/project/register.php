<?php
// register.php
// Dentist adds a new patient profile (first visit)

session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'dentist') {
  header('Location: login.php');
  exit;
}

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $fullName = trim($_POST['full_name'] ?? '');
  $dob      = trim($_POST['date_of_birth'] ?? '');
  $contact  = trim($_POST['contact_number'] ?? '');
  $email    = trim($_POST['email'] ?? '');

  if ($fullName === '') {
    $error = 'Full name is required.';
  } else {
    try {
      $stmt = $pdo->prepare("INSERT INTO patients (full_name, date_of_birth, contact_number, email) VALUES (?, ?, ?, ?)");
      $stmt->execute([
        $fullName,
        $dob !== '' ? $dob : null,
        $contact !== '' ? $contact : null,
        $email !== '' ? $email : null,
      ]);
      $newId = (int)$pdo->lastInsertId();

      // Redirect back to dashboard with preselected patient
      header('Location: dentist.php?patient_id=' . $newId);
      exit;
    } catch (Throwable $e) {
      $error = 'Failed to add patient: ' . $e->getMessage();
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dent AI | Add Patient</title>
  <link rel="stylesheet" href="assets/css/style.css" />
  <style>
    .form-wrap{max-width:900px;margin:28px auto;padding:20px;}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
    .grid .full{grid-column:1/-1;}
    .field input{width:100%;padding:12px 14px;border-radius:12px;border:1px solid rgba(0,0,0,.12);outline:none;}
    .msg{margin:10px 0;padding:10px 12px;border-radius:12px;}
    .msg.err{background:#ffe3e3;}
    .msg.ok{background:#e7ffe7;}
  </style>
</head>
<body>

<nav class="nav nav-three">
  <a href="dentist.php" class="brand"><span class="logo">🦷</span> DENT AI</a>
  <ul class="menu">
    <li><a href="dentist.php">DASHBOARD</a></li>
    
    <li><a href="profile.php">PROFILE</a></li>
    <li><a href="settings.php">SETTINGS</a></li>
  </ul>
</nav>

<div class="container form-wrap">
  <h2 style="margin:0 0 6px;">Add New Patient</h2>
  <p style="margin:0 0 16px; opacity:.85;">Register a patient profile for first-time visit.</p>

  <?php if ($error): ?>
    <div class="msg err"><?= h($error) ?></div>
  <?php endif; ?>

  <form method="post" autocomplete="off">
    <div class="grid">
      <div class="field full">
        <input type="text" name="full_name" placeholder="Full Name" required value="<?= h($_POST['full_name'] ?? '') ?>" />
      </div>
      <div class="field">
        <input type="date" name="date_of_birth" placeholder="Date of Birth" value="<?= h($_POST['date_of_birth'] ?? '') ?>" />
      </div>
      <div class="field">
        <input type="text" name="contact_number" placeholder="Contact Number" value="<?= h($_POST['contact_number'] ?? '') ?>" />
      </div>
      <div class="field full">
        <input type="email" name="email" placeholder="Email" value="<?= h($_POST['email'] ?? '') ?>" />
      </div>
    </div>

    <div style="display:flex; gap:10px; justify-content:flex-end; margin-top:14px;">
      <a class="action-btn" href="dentist.php" style="background:#ddd; color:#111;">Cancel</a>
      <button class="action-btn" type="submit">Save Patient</button>
    </div>
  </form>
</div>

</body>
</html>
