<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
  header("Location: login.php");
  exit;
}

$userId = (int)$_SESSION['user_id'];
$role   = strtolower($_SESSION['role']);

// Role-based back destination
$backPage = ($role === 'dentist') ? 'dentist.php' : 'patient.php';


// ✅ admin tak perlu profile
if ($role === 'admin') {
  header("Location: admindashboard.php");
  exit;
}

// map table ikut role
if ($role === 'dentist') { $table='dentists'; $pk='dentist_id'; }
else { $table='patients'; $pk='patient_id'; $role='patient'; }

$stmt = $pdo->prepare("SELECT * FROM $table WHERE $pk = ? LIMIT 1");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) { header("Location: logout.php"); exit; }

$fullName = $user['full_name'] ?? '';
$contact  = $user['contact_number'] ?? '';
$dob      = $user['date_of_birth'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dent AI | Profile</title>
  <link rel="stylesheet" href="assets/css/style.css" />
</head>

<body>
  <div class="container">
    <nav class="nav nav-three">
      <a href="<?= $backPage ?>" class="back"><span class="arrow">←</span> Back</a>
      <a href="index.php" class="brand"><span class="logo">🦷</span> DENT AI</a>
      <ul class="menu">
        <li><a href="index.php">HOME</a></li>
        <li><a href="aboutus.php">ABOUT US</a></li>
        <li><a href="contact.php">CONTACT</a></li>
        <li><a href="settings.php">SETTINGS</a></li>
      </ul>
    </nav>

    <section class="profile-wrap">
      <header class="profile-head">
        <h1>User Profile</h1>
        <div class="logged-pill">
          <span id="rolePill"><?= htmlspecialchars(strtoupper($role)) ?></span>
          <span class="avatar-lg">👤</span>
        </div>
      </header>

      <form id="profileForm" class="profile-card" autocomplete="off">
        <div class="field">
          <label>Full Name</label>
          <input type="text" id="fullName" value="<?= htmlspecialchars($fullName) ?>" placeholder="Enter your name" required />
        </div>

        <div class="field">
          <label>Role</label>
          <input type="text" id="role" value="<?= htmlspecialchars($role) ?>" disabled />
        </div>

        <div class="field" id="dobField" style="<?= ($role === 'patient') ? '' : 'display:none;' ?>">
          <label>Date of Birth</label>
          <input type="date" id="dob" value="<?= htmlspecialchars($dob) ?>" <?= ($role === 'patient') ? 'required' : '' ?> />
        </div>

        <div class="field">
          <label>Contact Number</label>
          <input type="tel" id="contact" value="<?= htmlspecialchars($contact) ?>" placeholder="+60XXXXXXXXX" required />
        </div>

        <div class="field">
          <label>User ID</label>
          <input type="text" id="userId" value="<?= (int)$userId ?>" disabled />
        </div>

        <div class="btn-row">
          <button type="button" class="btn-outline" id="editBtn">Edit</button>
          <button type="submit" class="btn-primary" id="saveBtn" disabled>Save Changes</button>
        </div>
      </form>
    </section>
  </div>

  <script>
    const ROLE = <?= json_encode($role) ?>;

    const fullName = document.getElementById('fullName');
    const dob = document.getElementById('dob');
    const contact = document.getElementById('contact');
    const saveBtn = document.getElementById('saveBtn');
    const editBtn = document.getElementById('editBtn');

    const original = {
      fullName: fullName.value,
      dob: dob ? dob.value : '',
      contact: contact.value
    };

    function setEditable(enabled) {
      fullName.disabled = !enabled;
      contact.disabled = !enabled;
      if (ROLE === 'patient' && dob) dob.disabled = !enabled;
      saveBtn.disabled = !enabled;
      editBtn.textContent = enabled ? 'Cancel' : 'Edit';
    }

    setEditable(false);

    editBtn.addEventListener('click', () => {
      const editing = !saveBtn.disabled;
      if (editing) {
        fullName.value = original.fullName;
        contact.value = original.contact;
        if (ROLE === 'patient' && dob) dob.value = original.dob;
        setEditable(false);
      } else {
        setEditable(true);
      }
    });

    document.getElementById('profileForm').addEventListener('submit', async (e) => {
      e.preventDefault();

      const payload = {
        full_name: fullName.value.trim(),
        contact_number: contact.value.trim(),
        date_of_birth: (ROLE === 'patient' && dob) ? dob.value : ''
      };

      try {
        const res = await fetch('profile_update.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const json = await res.json().catch(()=>({}));
        if (!res.ok || !json.ok) throw new Error(json.error || 'Update failed');

        original.fullName = payload.full_name;
        original.contact = payload.contact_number;
        if (ROLE === 'patient' && dob) original.dob = payload.date_of_birth;

        setEditable(false);
        alert('Profile updated ✅');
      } catch (err) {
        alert('Update failed: ' + err.message);
      }
    });
  </script>
</body>
</html>
