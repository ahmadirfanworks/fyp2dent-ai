<?php
session_start();
require 'db.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'dentist') {
    echo json_encode(['ok' => false, 'error' => 'Unauthorized']);
    exit;
}

$dentistId = (int)$_SESSION['user_id'];
$patientId = (int)($_POST['patient_id'] ?? 0);

if ($patientId <= 0 || !isset($_FILES['xray_image'])) {
    echo json_encode(['ok' => false, 'error' => 'Data tidak lengkap.']);
    exit;
}

// 1. Simpan fail ke folder tempatan
$uploadDir = __DIR__ . '/uploads/xrays';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0775, true);

$fileExt = pathinfo($_FILES['xray_image']['name'], PATHINFO_EXTENSION);
$newName = 'xray_' . time() . '.' . $fileExt;
$destPath = $uploadDir . '/' . $newName;

if (!move_uploaded_file($_FILES['xray_image']['tmp_name'], $destPath)) {
    echo json_encode(['ok' => false, 'error' => 'Gagal simpan imej di server.']);
    exit;
}

$filePathWeb = 'uploads/xrays/' . $newName;

// 2. Persediaan cURL untuk API
$AI_API_URL = 'https://dent-ai.onrender.com/api/v1/predict?threshold=0.3'; 

$aiStatus = 'FAILED';
$aiRaw = null;
$diagnosisSummary = 'AI analysis failed. Manual review required.';

try {
    $ch = curl_init();

    // Dapatkan MIME type yang betul (cth: image/jpeg atau image/png)
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($destPath);

    // Bina data post menggunakan CURLFile dengan parameter yang tepat
    $postData = [
        'file' => new CURLFile($destPath, $mimeType, $newName)
    ];

    curl_setopt_array($ch, [
        CURLOPT_URL => $AI_API_URL,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_TIMEOUT => 90,
        CURLOPT_HTTPHEADER => [
            'accept: application/json',
            'Content-Type: multipart/form-data'
        ],
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($httpCode == 200 && $response) {
        $aiRaw = $response;
        $aiJson = json_decode($response, true);
        $aiStatus = 'SUCCESS';
        $diagnosisSummary = $aiJson['summary'] ?? 'Analysis complete.';
    } else {
        // Jika 400, simpan response body untuk tahu apa yang API tak suka
        $errorDetail = $response ?: $curlError;
        throw new Exception("HTTP $httpCode: $errorDetail");
    }
} catch (Exception $e) {
    $aiStatus = 'FAILED';
    $aiRaw = json_encode(['error' => $e->getMessage()]);
}

// 3. Simpan ke Database
try {
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("INSERT INTO xray_images (patient_id, dentist_id, file_path, uploaded_at, ai_status, ai_raw_result) VALUES (?, ?, ?, NOW(), ?, ?)");
    $stmt->execute([$patientId, $dentistId, $filePathWeb, $aiStatus, $aiRaw]);
    $xrayId = $pdo->lastInsertId();

    $stmt = $pdo->prepare("INSERT INTO diagnosis_reports (patient_id, dentist_id, xray_id, diagnosis_date, diagnosis_result, created_at) VALUES (?, ?, ?, CURDATE(), ?, NOW())");
    $stmt->execute([$patientId, $dentistId, $xrayId, $diagnosisSummary]);
    $reportId = $pdo->lastInsertId();

    $pdo->commit();
    echo json_encode(['ok' => true, 'report_id' => $reportId]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}