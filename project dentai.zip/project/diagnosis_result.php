<?php
session_start();
require 'db.php';

// Guard: Hanya doktor gigi yang sah boleh masuk
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'dentist') {
  header("Location: login.php");
  exit;
}

$reportId = (int)($_GET['report_id'] ?? 0);
if ($reportId <= 0) {
  die("Error: Report ID tidak sah.");
}

// Ambil data lengkap laporan, pesakit, imej, dan doktor
$stmt = $pdo->prepare("
  SELECT 
    dr.report_id, dr.diagnosis_date, dr.diagnosis_result, dr.prescription, dr.created_at,
    p.patient_id, p.full_name AS patient_name, p.email AS patient_email,
    p.contact_number AS patient_contact, p.date_of_birth AS patient_dob,
    xi.xray_id, xi.file_path, xi.annotated_file_path, xi.ai_status, xi.ai_raw_result,
    d.full_name AS dentist_name
  FROM diagnosis_reports dr
  LEFT JOIN patients p ON p.patient_id = dr.patient_id
  LEFT JOIN xray_images xi ON xi.xray_id = dr.xray_id
  LEFT JOIN dentists d ON d.dentist_id = dr.dentist_id
  WHERE dr.report_id = ?
  LIMIT 1
");
$stmt->execute([$reportId]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
  die("Error: Laporan tidak dijumpai.");
}

// --- LOGIK PARSING DATA AI ---
$aiData = json_decode($row['ai_raw_result'], true) ?: [];
$findings = $aiData['diagnoses'] ?? []; 
$recommendations = $aiData['recommendations'] ?? []; 
$summary = $row['diagnosis_result'] ?: 'No summary available.';

function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$displayImg = $row['annotated_file_path'] ?: $row['file_path'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dent AI | Official Report</title>
  <link rel="stylesheet" href="assets/css/style.css" />
  <style>
    /* CSS untuk memastikan nav-three kelihatan seperti analyzenow.php */
    .nav-three {
      background: white !important;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 30px;
      height: 70px;
    }
    
    .nav-three .back {
      text-decoration: none;
      color: #143d17;
      font-weight: 700;
      font-size: 1.1rem;
    }
    
    .nav-three .brand {
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      color: #143d17 !important;
      font-weight: 800;
      font-size: 1.4rem;
      text-decoration: none;
    }

    /* UI Badges */
    .badge { padding:5px 15px; border-radius:20px; font-size:11px; font-weight:bold; text-transform:uppercase; color: white; display: inline-block; }
    .badge-high { background:#ff4d4d; }
    .badge-moderate { background:#ffa500; }
    .badge-low { background:#28a745; }
    .badge-status { background: #28a745; }

    /* Panels & Layout */
    .panel { background: rgba(255,255,255,0.08); padding: 20px; border-radius: 12px; margin-bottom: 20px; border: 1px solid rgba(255,255,255,0.1); }
    .panel h3 { margin-top: 0; color: #a2ffaf; font-size: 1rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 15px; }
    
    .diag-item { display: flex; justify-content: space-between; align-items: flex-start; padding: 15px 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
    .img-main { width: 100%; border-radius: 10px; border: 1px solid rgba(255,255,255,0.2); }

    /* Progress Bar */
    .progress-bg { width: 100%; background: rgba(255,255,255,0.1); height: 6px; border-radius: 3px; margin-top: 8px; overflow: hidden; }
    .progress-fill { background: #a2ffaf; height: 100%; border-radius: 3px; }

    textarea { width: 100%; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.2); color: white; padding: 12px; border-radius: 8px; font-family: inherit; resize: vertical; }
    .btn-save { background: #fff; color: #000; border: none; padding: 8px 20px; border-radius: 5px; cursor: pointer; font-weight: bold; margin-top: 10px; }

    @media print {
      .nav-three, .action-buttons, .btn-save { display: none !important; }
      body { background: white !important; color: black !important; background-image: none !important; }
      .container { padding-top: 0 !important; }
      .panel { background: white !important; color: black !important; border: 1px solid #ddd !important; box-shadow: none !important; }
      .panel h3 { color: black !important; border-bottom: 2px solid #000; }
      .progress-bg { border: 1px solid #ccc; }
      .progress-fill { background: #333 !important; }
      .img-main { border: 1px solid #000; }
      textarea { color: black; border: 1px solid #ccc; }
    }
  </style>
</head>
<body>

  <nav class="nav nav-three">
    <a href="analyzenow.php?patient_id=<?= $row['patient_id'] ?>" class="back">← Back</a>
    <a href="index.php" class="brand">🦷 DENT AI</a>
    <div></div> </nav>

<section class="container" style="padding-top: 40px;">
  <div class="diagnosis-page">
    
    <div class="diagnosis-card" style="text-align: left;">
      <h2 style="font-size: 2.2rem; margin-bottom: 5px;">Diagnosis Report</h2>
      <p style="opacity: 0.6; margin-bottom: 30px;">Generated by Dent AI Diagnostic Engine v1.0</p>

      <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap:20px; margin-bottom:40px; background:rgba(255,255,255,0.05); padding:25px; border-radius:12px;">
        <div>
          <small style="opacity:0.5; text-transform:uppercase;">Patient Name</small>
          <div style="font-size: 1.1rem; font-weight: bold;"><?= h($row['patient_name']) ?></div>
          <small><?= h($row['patient_email']) ?></small>
        </div>
        <div>
          <small style="opacity:0.5; text-transform:uppercase;">Dentist In Charge</small>
          <div style="font-weight: bold;"><?= h($row['dentist_name']) ?></div>
          <small><?= date('d M Y', strtotime($row['created_at'])) ?></small>
        </div>
        <div>
          <small style="opacity:0.5; text-transform:uppercase;">AI Status</small>
          <div>
            <span class="badge badge-status">SUCCESS</span>
          </div>
        </div>
        <div style="text-align: right;">
          <small style="opacity:0.5; text-transform:uppercase;">Report ID</small>
          <div style="font-family: monospace; font-weight: bold;">#<?= str_pad($row['report_id'], 5, '0', STR_PAD_LEFT) ?></div>
        </div>
      </div>

      <div style="display: grid; grid-template-columns: 1.2fr 1fr; gap: 40px;">
        
        <div>
          <img src="<?= h($displayImg) ?>" class="img-main" alt="Dental X-ray">
          <p style="font-size:0.8rem; text-align:center; margin-top:12px; opacity:0.5; font-style: italic;">
            Radiograph Analysis Image (<?= $row['annotated_file_path'] ? "Annotated" : "Original" ?>)
          </p>
          
          <div class="panel" style="margin-top: 30px;">
            <h3>Clinical Notes & Prescription</h3>
            <form action="update_prescription.php" method="POST">
              <input type="hidden" name="report_id" value="<?= $row['report_id'] ?>">
              <textarea name="prescription" rows="4" placeholder="Enter clinical observations..."><?= h($row['prescription']) ?></textarea>
              <button type="submit" class="btn-save">Save Observation</button>
            </form>
          </div>
        </div>

        <div>
          <div class="panel">
            <h3>Automated Summary</h3>
            <p style="line-height:1.7; font-size: 0.95rem;"><?= h($summary) ?></p>
          </div>

          <div class="panel">
            <h3>Detected Findings</h3>
            <?php if (!empty($findings)): ?>
              <?php foreach ($findings as $f): 
                $sev = strtolower($f['severity'] ?? 'low');
                $badgeClass = "badge-" . ($sev == 'high' ? 'high' : ($sev == 'moderate' ? 'moderate' : 'low'));
                $confPercent = round(($f['confidence'] ?? 0) * 100, 1);
              ?>
                <div class="diag-item">
                  <div style="flex: 1;">
                    <strong style="font-size: 1.05rem;"><?= h($f['condition']) ?></strong>
                    <div style="font-size: 0.85rem; opacity: 0.7; margin-top: 4px;"><?= h($f['description'] ?? '') ?></div>
                  </div>
                  <div style="text-align: right; min-width: 100px; margin-left: 15px;">
                    <span class="badge <?= $badgeClass ?>"><?= h($f['severity']) ?></span>
                    <div class="progress-bg">
                      <div class="progress-fill" style="width: <?= $confPercent ?>%;"></div>
                    </div>
                    <small style="font-size: 10px; opacity: 0.6;"><?= $confPercent ?>% Confidence</small>
                  </div>
                </div>
              <?php endforeach; ?>
            <?php else: ?>
              <p style="opacity:0.5; padding: 10px 0;">No pathologies detected.</p>
            <?php endif; ?>
          </div>

          <div class="panel">
            <h3>AI Recommendations</h3>
            <ul style="padding-left:18px; line-height:1.8; font-size: 0.9rem; margin: 0;">
              <?php foreach ($recommendations as $rec): ?>
                <li style="margin-bottom: 5px;"><?= h($rec) ?></li>
              <?php endforeach; ?>
            </ul>
          </div>

          <div class="action-buttons" style="display:flex; gap:12px; justify-content:flex-end; margin-top: 20px;">
            <button onclick="window.print()" style="background:transparent; border:1px solid white; color:white; padding: 10px 25px; border-radius:5px; cursor:pointer;">Print Report</button>
            <a href="analyzenow.php?patient_id=<?= $row['patient_id'] ?>" style="background:#fff; color:#000; padding: 10px 25px; border-radius:5px; text-decoration:none; font-weight:bold;">New Analysis</a>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>

</body>
</html>