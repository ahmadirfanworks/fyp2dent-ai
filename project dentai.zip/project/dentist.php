<?php
session_start();
require 'db.php';

// Guard: dentist only
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'dentist') {
  header('Location: login.php');
  exit;
}

$dentistId = (int)$_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM dentists WHERE dentist_id = ? LIMIT 1");
$stmt->execute([$dentistId]);
$d = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$d) {
  die('Dentist record not found.');
}

$fullName = $d['full_name'] ?? 'Full Name';
$did      = $d['dentist_id'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dent AI | Dentist Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css" />
  <style>
    /* 🎨 Background consistency */
    body {
      font-family: 'Poppins', sans-serif;
      background-image: url("assets/img/background.png"); /* Pastikan path ini betul */
      background-size: cover;
      background-attachment: fixed;
      color: white;
      margin: 0;
    }

    /* ⚪ TOP BAR (Follows analyzenow.php style) */
    .nav-three {
      background: white !important;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 30px;
      height: 70px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .nav-three .back {
      text-decoration: none;
      color: #143d17;
      font-weight: 700;
      font-size: 1.1rem;
    }
    .nav-three .brand {
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      color: #143d17 !important;
      font-weight: 800;
      font-size: 1.4rem;
      text-decoration: none;
    }

    .container { padding: 40px 50px; }

    /* 👨‍⚕️ DENTIST PROFILE CARD */
    .dentist-card {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 20px;
      padding: 20px 30px;
      display: flex;
      align-items: center;
      gap: 20px;
      margin-bottom: 30px;
    }
    .dentist-card .avatar { font-size: 40px; background: white; border-radius: 50%; padding: 10px; }

    /* 🔎 SEARCH PANEL */
    .main-panel {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(15px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 25px;
      padding: 30px;
    }

    .search-input-group { position: relative; width: 100%; margin-bottom: 30px; }
    .search-input-group input {
      width: 100%;
      padding: 18px 25px;
      border-radius: 40px;
      border: none;
      background: rgba(255,255,255,0.95);
      color: #333;
      font-size: 16px;
      outline: none;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      font-family: inherit;
    }

    /* 📊 GRID SECTION */
    .grid-container { display: grid; grid-template-columns: 1fr 2fr; gap: 25px; }
    .sub-panel { background: rgba(0,0,0,0.2); border-radius: 20px; padding: 25px; border: 1px solid rgba(255,255,255,0.05); }
    
    .kv-row { margin-bottom: 18px; }
    .kv-row strong { display: block; opacity: 0.6; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; }
    .kv-row span { font-size: 16px; font-weight: 600; display: block; margin-top: 2px; }

    /* 📜 HISTORY TABLE */
    .history-table { width: 100%; border-collapse: collapse; }
    .history-table th { text-align: left; font-size: 11px; opacity: 0.5; padding-bottom: 10px; border-bottom: 1px solid rgba(255,255,255,0.1); text-transform: uppercase; }
    .history-table td { padding: 15px 0; font-size: 13px; border-bottom: 1px solid rgba(255,255,255,0.05); }

    .btn-view { background: #a2ffaf; color: #0d3c0d; padding: 6px 14px; border-radius: 15px; text-decoration: none; font-size: 11px; font-weight: 800; }
    .btn-main { background: white; color: #143d17; text-align: center; border-radius: 30px; padding: 16px; text-decoration: none; font-weight: 800; display: block; margin-top: 20px; transition: 0.3s; }
    .btn-main:hover:not(.btn-disabled) { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.2); }
    .btn-disabled { opacity: 0.3; pointer-events: none; }

    .results-dropdown {
      position: absolute; width: 100%; background: white; color: #333; 
      border-radius: 20px; margin-top: 8px; display: none; z-index: 100; box-shadow: 0 10px 30px rgba(0,0,0,0.2);
      overflow: hidden;
    }
    .result-item { padding: 15px 25px; cursor: pointer; border-bottom: 1px solid #eee; transition: 0.2s; }
    .result-item:hover { background: #f4f4f4; }
    .result-item:last-child { border-bottom: none; }
  </style>
</head>
<body>

  <nav class="nav nav-three">
    <a href="index.php" class="back">← Back</a>
    <a href="index.php" class="brand">🦷 DENT AI</a>
    <div style="width:60px"></div> </nav>

  <div class="container">
    <div class="dentist-card">
      <img src="assets/img/profile-icon.png" alt="Doctor" style="height: 60px; border-radius: 50%; background: white; padding: 5px;">
      <div>
        <h2 style="margin:0; font-weight: 800;"><?php echo htmlspecialchars($fullName); ?></h2>
        <p style="margin:0; opacity:0.7;">Dentist ID: #<?php echo htmlspecialchars((string)$did); ?></p>
      </div>
      <div style="margin-left: auto;">
         <a href="logout.php" style="color:#ff5f5f; text-decoration:none; font-weight:bold; font-size:13px;">LOGOUT</a>
      </div>
    </div>

    <div class="main-panel">
      <div class="search-box-wrapper">
        <h3 style="margin:0 0 15px 10px; font-size: 1.2rem; font-weight: 700;">Patient Search / History</h3>
        <div class="search-input-group">
          <input id="patientSearch" type="text" placeholder="Type patient name or email to search..." onkeyup="triggerSearch()" autocomplete="off">
          <div id="searchResults" class="results-dropdown"></div>
        </div>
      </div>

      <div class="grid-container">
        <div class="sub-panel">
          <h4 style="margin-top:0; color:#a2ffaf; font-size: 0.8rem; letter-spacing: 1px;">PATIENT PROFILE</h4>
          <div id="patientDetails">
            <p style="opacity: 0.5; font-size: 0.9rem;">Search and select a patient to view details.</p>
          </div>
          <a id="btnStart" class="btn-main btn-disabled" href="#">+ START NEW ANALYSIS</a>
          <a href="register.php" style="display:block; text-align:center; color:white; font-size:12px; margin-top:15px; text-decoration:none; opacity:0.6;">Register New Patient</a>
        </div>

        <div class="sub-panel">
          <h4 style="margin-top:0; color:#a2ffaf; font-size: 0.8rem; letter-spacing: 1px;">DIAGNOSIS HISTORY</h4>
          <div id="historyWrap">
            <p style="opacity: 0.5; font-size: 0.9rem;">No history to display.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    const elSearch = document.getElementById('patientSearch');
    const elResults = document.getElementById('searchResults');
    const elDetails = document.getElementById('patientDetails');
    const elHistory = document.getElementById('historyWrap');
    const btnStart = document.getElementById('btnStart');

    function triggerSearch() {
      const q = elSearch.value.trim();
      if (q.length < 2) { elResults.style.display = 'none'; return; }

      fetch('patient_search.php?q=' + encodeURIComponent(q))
        .then(r => r.json())
        .then(list => {
          elResults.innerHTML = '';
          if (list.length === 0) {
            elResults.innerHTML = '<div class="result-item">No matches found.</div>';
          } else {
            list.forEach(p => {
              const div = document.createElement('div');
              div.className = 'result-item';
              div.innerHTML = `<strong>${p.full_name}</strong><br><small style="color:#666">${p.email}</small>`;
              div.onclick = () => {
                elSearch.value = p.full_name;
                elResults.style.display = 'none';
                loadPatient(p);
              };
              elResults.appendChild(div);
            });
          }
          elResults.style.display = 'block';
        });
    }

    function loadPatient(p) {
      btnStart.classList.remove('btn-disabled');
      btnStart.href = 'analyzenow.php?patient_id=' + p.patient_id;

      elDetails.innerHTML = `
        <div class="kv-row"><strong>NAME</strong><span>${p.full_name}</span></div>
        <div class="kv-row"><strong>DOB</strong><span>${p.date_of_birth || 'N/A'}</span></div>
        <div class="kv-row"><strong>PHONE</strong><span>${p.contact_number || 'N/A'}</span></div>
        <div class="kv-row"><strong>EMAIL</strong><span>${p.email}</span></div>
      `;

      fetch('patient_history.php?patient_id=' + p.patient_id)
        .then(r => r.json())
        .then(data => {
          if (!data.history || data.history.length === 0) {
            elHistory.innerHTML = '<p style="opacity:0.5;">No history found for this patient.</p>';
          } else {
            let html = '<table class="history-table"><thead><tr><th>DATE</th><th>RESULT</th><th>ACTION</th></tr></thead><tbody>';
            data.history.forEach(h => {
              html += `<tr>
                <td>${h.created_at.split(' ')[0]}</td>
                <td style="max-width:180px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${h.diagnosis_result}</td>
                <td><a href="diagnosis_result.php?report_id=${h.report_id}" class="btn-view">VIEW</a></td>
              </tr>`;
            });
            html += '</tbody></table>';
            elHistory.innerHTML = html;
          }
        });
    }

    document.addEventListener('click', (e) => {
      if (e.target !== elSearch) elResults.style.display = 'none';
    });
  </script>
</body>
</html>