<?php
session_start();
require 'db.php';

// Guard: Hanya patient boleh masuk
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'patient') {
  header("Location: login.php");
  exit;
}

$patientId = (int)$_SESSION['user_id'];

// 1. Ambil senarai tahun unik
$stmtYears = $pdo->prepare("
  SELECT DISTINCT YEAR(diagnosis_date) AS yr 
  FROM diagnosis_reports 
  WHERE patient_id = ? 
  ORDER BY yr DESC
");
$stmtYears->execute([$patientId]);
$years = $stmtYears->fetchAll(PDO::FETCH_ASSOC);

$selectedYear = isset($_GET['year']) ? (int)$_GET['year'] : ($years[0]['yr'] ?? date('Y'));

// 2. Ambil senarai diagnosis untuk tahun dipilih
$stmtList = $pdo->prepare("
  SELECT report_id, diagnosis_date, diagnosis_result 
  FROM diagnosis_reports 
  WHERE patient_id = ? AND YEAR(diagnosis_date) = ?
  ORDER BY diagnosis_date DESC
");
$stmtList->execute([$patientId, $selectedYear]);
$reports = $stmtList->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dent AI | Diagnosis History</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    .history-container {
      display: grid;
      grid-template-columns: 350px 1fr;
      gap: 20px;
      margin-top: 20px;
      height: 75vh;
    }

    .side-list {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      padding: 20px;
      overflow-y: auto;
      border: 1px solid rgba(255,255,255,0.1);
    }

    .year-filter {
      width: 100%;
      padding: 10px;
      border-radius: 10px;
      margin-bottom: 20px;
      background: #1e5920;
      color: white;
      border: 1px solid var(--accent);
    }

    .report-item {
      padding: 15px;
      background: rgba(255,255,255,0.05);
      border-radius: 15px;
      margin-bottom: 10px;
      cursor: pointer;
      transition: 0.3s;
      border: 1px solid transparent;
    }

    .report-item:hover, .report-item.active {
      background: #71ec71;
      color: #0d3c0d;
    }

    .report-display {
      background: white;
      color: #333;
      border-radius: 20px;
      padding: 40px;
      overflow-y: auto;
      border: 1px solid #eee;
    }

    .no-selection {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100%;
      color: #999;
      flex-direction: column;
    }

    .download-btn {
      display: inline-block;
      margin-top: 30px;
      padding: 12px 25px;
      background: #143d17;
      color: white;
      border: none;
      border-radius: 50px;
      font-weight: bold;
      cursor: pointer;
    }

    .download-btn:hover { background: #1e5920; }

    /* 🖨️ CSS KHUSUS UNTUK PRINT/PDF */
    @media print {
      body * { visibility: hidden; } /* Sembunyikan semua benda */
      #reportView, #reportView * { visibility: visible; } /* Tunjukkan report sahaja */
      #reportView {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        border: none;
        padding: 0;
      }
      .download-btn, .nav, .side-list, h2 { display: none !important; } /* Buang butang & nav dari PDF */
    }
  </style>
</head>
<body class="patient-page">

<div class="container">
  <nav class="nav">
    <a class="brand" href="patient.php">🦷 DENT AI</a>
    <ul class="menu">
      <li><a href="patient.php">DASHBOARD</a></li>
      <li><a href="profile.php">PROFILE</a></li>
      <li><a href="logout.php">LOGOUT</a></li>
    </ul>
  </nav>

  <h2 style="margin-top:20px;">Diagnosis History</h2>

  <div class="history-container">
    
    <div class="side-list">
      <form method="GET" id="yearForm">
        <label style="font-size: 12px; opacity: 0.7;">SELECT YEAR:</label>
        <select name="year" class="year-filter" onchange="document.getElementById('yearForm').submit()">
          <?php foreach ($years as $y): ?>
            <option value="<?= $y['yr'] ?>" <?= $selectedYear == $y['yr'] ? 'selected' : '' ?>>
              <?= $y['yr'] ?>
            </option>
          <?php endforeach; ?>
          <?php if (!$years): ?> <option>No records</option> <?php endif; ?>
        </select>
      </form>

      <div id="reportList">
        <?php if ($reports): ?>
          <?php foreach ($reports as $r): ?>
            <div class="report-item" onclick="loadReport(<?= $r['report_id'] ?>, this)">
              <h4><?= date('d M Y', strtotime($r['diagnosis_date'])) ?></h4>
              <small><?= substr(htmlspecialchars($r['diagnosis_result']), 0, 35) ?>...</small>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p style="text-align:center; opacity:0.5;">No records for <?= $selectedYear ?></p>
        <?php endif; ?>
      </div>
    </div>

    <div class="report-display" id="reportView">
      <div class="no-selection">
        <span style="font-size: 50px;">📄</span>
        <p>Please select a record from the left to view the report.</p>
      </div>
    </div>

  </div>
</div>

<script>
function loadReport(reportId, element) {
    document.querySelectorAll('.report-item').forEach(item => item.classList.remove('active'));
    element.classList.add('active');

    const reportView = document.getElementById('reportView');
    reportView.innerHTML = '<div class="no-selection"><p>Loading report...</p></div>';

    fetch('get_report_detail.php?id=' + reportId)
      .then(response => response.json())
      .then(data => {
        if(data.error) {
          reportView.innerHTML = `<div class="no-selection"><p>${data.error}</p></div>`;
          return;
        }

        reportView.innerHTML = `
          <div class="report-content">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; border-bottom: 2px solid #143d17; padding-bottom:15px;">
                <div>
                    <h1 style="margin:0; color:#143d17;">DENT AI</h1>
                    <h2 style="margin:0; font-size:18px;">Diagnosis Report</h2>
                    <p style="color:#666; margin:5px 0 0 0;">Date: ${data.diagnosis_date}</p>
                </div>
                <div style="text-align:right;">
                    <span style="background:#e8f5e9; color:#2e7d32; padding:5px 15px; border-radius:20px; font-weight:bold; font-size:12px;">OFFICIAL RECORD</span>
                </div>
            </div>
            
            <div style="margin-top:30px;">
                <h4 style="margin-bottom:5px; color:#143d17;">DIAGNOSIS RESULT:</h4>
                <p style="line-height:1.6; font-size:15px; background:#f9f9f9; padding:15px; border-radius:10px;">${data.diagnosis_result}</p>
            </div>

            <div style="margin-top:20px;">
                <h4 style="margin-bottom:5px; color:#143d17;">PRESCRIPTION / ADVICE:</h4>
                <p style="line-height:1.6; color:#555; padding:0 15px;">${data.prescription || 'No specific prescription provided.'}</p>
            </div>

            <div style="margin-top:40px; font-size:11px; color:#999; border-top:1px solid #eee; padding-top:10px; text-align:center;">
                This report is generated by Dent AI System. Please consult a dentist for clinical verification.
            </div>
            
            <button onclick="window.print()" class="download-btn">
               SAVE AS PDF / PRINT
            </button>
          </div>
        `;
      })
      .catch(err => {
        reportView.innerHTML = `<div class="no-selection"><p>Error loading report.</p></div>`;
      });
}
</script>

</body>
</html>