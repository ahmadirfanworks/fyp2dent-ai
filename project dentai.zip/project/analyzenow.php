<?php
session_start();
require 'db.php';

// Guard: dentist only
if (!isset($_SESSION['user_id']) || (($_SESSION['role'] ?? '') !== 'dentist')) {
  header("Location: login.php");
  exit;
}

$dentistId = (int)$_SESSION['user_id'];
$patientId = (int)($_GET['patient_id'] ?? 0);

$patient = null;
if ($patientId > 0) {
    // UPDATED: Using 'patient_id' from 'patients' table
    $stmt = $pdo->prepare("SELECT * FROM patients WHERE patient_id = ? LIMIT 1");
    $stmt->execute([$patientId]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);
}

$disabled = ($patientId <= 0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dent AI | Analyze Tool</title>
  <link rel="stylesheet" href="assets/css/style.css"/>
  <style>
    /* MAIN LAYOUT */
    .analyze-container {
      max-width: 1000px;
      margin: 40px auto;
      text-align: center;
      padding: 0 20px;
    }

    .main-title {
      font-size: 2.8rem;
      font-weight: 800;
      color: #fff;
      margin-bottom: 5px;
    }

    /* PATIENT INFO BAR */
    .patient-info-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(255, 255, 255, 0.12);
      backdrop-filter: blur(12px);
      padding: 18px 30px;
      border-radius: 20px;
      margin: 25px auto 35px;
      max-width: 850px;
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: #fff;
    }

    .info-item { text-align: left; }
    .info-item label {
      display: block;
      font-size: 0.7rem;
      text-transform: uppercase;
      opacity: 0.7;
      letter-spacing: 1.2px;
      margin-bottom: 6px; /* Space between label and content */
    }
    .info-item span { font-weight: 700; font-size: 1.1rem; }

    /* STATUS BADGE - Compact & Spaced */
    .status-badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 99px;
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      background: #48bb78; /* Default green */
      color: #fff;
    }

    /* UPLOAD ZONE */
    .upload-wrapper {
      display: flex;
      justify-content: center;
      margin-bottom: 30px;
    }

    .drop-zone {
      width: 100%;
      max-width: 750px;
      height: 420px;
      background: rgba(255, 255, 255, 0.08);
      border: 3px dashed rgba(255, 255, 255, 0.3);
      border-radius: 35px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
    }

    .drop-zone:hover, .drop-zone.drag-over {
      background: rgba(255, 255, 255, 0.15);
      border-color: #fff;
    }

    #previewImg {
      width: 100%;
      height: 100%;
      object-fit: contain;
      display: none;
    }

    .dz-placeholder { color: #fff; text-align: center; }
    .dz-placeholder i { font-size: 3.5rem; display: block; margin-bottom: 10px; }

    /* TUTORIAL SECTION */
    .tutorial-container {
      margin-top: 50px;
      background: rgba(0, 0, 0, 0.25);
      padding: 35px;
      border-radius: 25px;
    }

    .tutorial-container h2 {
      font-size: 2.2rem;
      font-weight: 800;
      color: #fff;
      margin-bottom: 25px;
    }

    .tutorial-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .tutorial-step {
      background: rgba(255, 255, 255, 0.05);
      padding: 20px;
      border-radius: 15px;
      color: #eee;
      border-left: 4px solid #4299e1;
      text-align: left;
    }

    .tutorial-step strong { color: #4299e1; display: block; margin-bottom: 5px; }

    .btn-analyze {
      padding: 18px 70px;
      font-size: 1.3rem;
      font-weight: 700;
      border-radius: 50px;
      border: none;
      cursor: pointer;
      background: #fff;
      color: #2b6cb0;
      transition: 0.3s;
    }

    .btn-analyze:disabled { opacity: 0.4; cursor: not-allowed; }
    .btn-analyze:hover:not(:disabled) { background: #2b6cb0; color: #fff; transform: translateY(-3px); }
  </style>
</head>
<body>

  <div class="container">
    <nav class="nav nav-three">
      <a href="dentist.php" class="back">← Back</a>
      <a href="index.php" class="brand">🦷 DENT AI</a>
    </nav>

    <div class="analyze-container">
      <h1 class="main-title">Analyze Tool</h1>

      <div class="patient-info-bar">
        <?php if ($patient): ?>
          <div class="info-item">
            <label>Patient ID</label>
            <span>#<?= str_pad($patient['patient_id'], 4, '0', STR_PAD_LEFT) ?></span>
          </div>
          <div class="info-item" style="flex:1; margin-left: 40px;">
            <label>Patient Name</label>
            <span><?= htmlspecialchars($patient['full_name']) ?></span>
          </div>
          <div class="info-item">
            <label>Current Status</label>
            <div>
                <span class="status-badge" id="statusBadge">Ready to Upload</span>
            </div>
          </div>
        <?php else: ?>
          <div class="info-item" style="flex:1; text-align:center;">
            <span style="color:#fc8181;">⚠️ No patient selected. Please select one from the dashboard.</span>
          </div>
        <?php endif; ?>
      </div>

      <div class="upload-wrapper">
        <div class="drop-zone" id="dropZone">
          <div class="dz-placeholder">
            <i>📂</i>
            <p><strong>Drag & Drop X-ray</strong> or Click to Browse</p>
            <p style="font-size: 0.8rem; opacity: 0.7;">PNG, JPG or WebP images only</p>
          </div>
          <img id="previewImg" alt="X-ray Preview">
          <input type="file" id="fileInput" hidden accept="image/*" <?= $disabled ? 'disabled' : '' ?>>
        </div>
      </div>

      <button id="analyzeBtn" class="btn-analyze" disabled>Start AI Analysis</button>

      <div class="tutorial-container">
        <h2>TUTORIAL</h2>
        <div class="tutorial-grid">
          <div class="tutorial-step">
            <strong>STEP 1</strong>
            <p>Select a patient from the Dentist Dashboard before starting the analysis process.</p>
          </div>
          <div class="tutorial-step">
            <strong>STEP 2</strong>
            <p>Upload a clear X-ray image. You can drag and drop the file directly into the box above.</p>
          </div>
          <div class="tutorial-step">
            <strong>STEP 3</strong>
            <p>Click 'Start AI Analysis' and wait for the system to automatically generate the report.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    const dz = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const previewImg = document.getElementById('previewImg');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const statusBadge = document.getElementById('statusBadge');
    const placeholder = dz.querySelector('.dz-placeholder');

    dz.addEventListener('click', () => { if(!fileInput.disabled) fileInput.click(); });

    dz.addEventListener('dragover', (e) => {
      e.preventDefault();
      if(!fileInput.disabled) dz.classList.add('drag-over');
    });

    dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));

    dz.addEventListener('drop', (e) => {
      e.preventDefault();
      dz.classList.remove('drag-over');
      if(fileInput.disabled) return;
      handleFile(e.dataTransfer.files[0]);
    });

    fileInput.addEventListener('change', (e) => {
      if(e.target.files.length) handleFile(e.target.files[0]);
    });

    function handleFile(file) {
      if (!file.type.startsWith('image/')) {
        alert('Invalid file type. Please upload an image (JPG, PNG, or WebP).');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        previewImg.src = e.target.result;
        previewImg.style.display = 'block';
        placeholder.style.display = 'none';
        analyzeBtn.disabled = false;
        
        if(statusBadge) {
          statusBadge.textContent = "Image Ready";
          statusBadge.style.background = "#3182ce"; // Change to blue when image loaded
        }
      };
      reader.readAsDataURL(file);

      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);
      fileInput.files = dataTransfer.files;
    }

    analyzeBtn.addEventListener('click', async () => {
      analyzeBtn.disabled = true;
      analyzeBtn.textContent = "Analyzing...";

      const fd = new FormData();
      fd.append('xray_image', fileInput.files[0]);
      fd.append('patient_id', <?= $patientId ?>);

      try {
        const res = await fetch('analyzenow_process.php', {
          method: 'POST',
          body: fd
        });
        const json = await res.json();

        if (json.ok) {
          window.location.href = 'diagnosis_result.php?report_id=' + json.report_id;
        } else {
          alert(json.error || "Analysis failed. Please try again.");
          analyzeBtn.disabled = false;
          analyzeBtn.textContent = "Start AI Analysis";
        }
      } catch (err) {
        alert("System error. Please check your connection.");
        analyzeBtn.disabled = false;
        analyzeBtn.textContent = "Start AI Analysis";
      }
    });
  </script>
</body>
</html>