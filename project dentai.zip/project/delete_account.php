<?php
session_start();
require 'db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
  http_response_code(401);
  echo json_encode(['ok'=>false,'error'=>'Not logged in']);
  exit;
}

$userId = (int)$_SESSION['user_id'];
$role   = strtolower($_SESSION['role']);

if ($role === 'admin') {
  $table = 'admins';   $pk = 'admin_id';
} elseif ($role === 'dentist') {
  $table = 'dentists'; $pk = 'dentist_id';
} else {
  $table = 'patients'; $pk = 'patient_id';
}

try {
  $stmt = $pdo->prepare("DELETE FROM $table WHERE $pk = ? LIMIT 1");
  $stmt->execute([$userId]);

  // clear session after delete
  session_unset();
  session_destroy();

  echo json_encode(['ok'=>true]);
} catch (PDOException $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
