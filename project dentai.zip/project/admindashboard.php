<?php
session_start();
require 'db.php';

/* ===== ADMIN GUARD ===== */
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: login.php");
    exit;
}

/* ===== FETCH DATA ===== */
$patients = $pdo->query("
    SELECT 
        patient_id AS id,
        full_name,
        email
    FROM patients
    ORDER BY patient_id DESC
")->fetchAll();

$dentists = $pdo->query("
    SELECT 
        dentist_id AS id,
        full_name,
        email
    FROM dentists
    ORDER BY dentist_id DESC
")->fetchAll();

/* ===== PREPARE DATA FOR JS ===== */
$data = [
    'patient' => array_map(fn($p) => [
        'id' => $p['id'],
        'name' => $p['full_name'],
        'email' => $p['email'],
        'password' => '••••••••'
    ], $patients),

    'dentist' => array_map(fn($d) => [
        'id' => $d['id'],
        'name' => $d['full_name'],
        'email' => $d['email'],
        'password' => '••••••••'
    ], $dentists),
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dent AI | Admin Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<div class="container">

  <!-- 🌿 Navigation -->
  <nav class="nav nav-three">
    <a href="index.php" class="back">
      <span class="arrow">←</span> Back
    </a>

    <a href="index.php" class="brand">
      <span class="logo">🦷</span> DENT AI
    </a>

    <ul class="menu">
      <li><a href="index.php">HOME</a></li>
      <li><a href="aboutus.php">ABOUT US</a></li>
      <li><a href="contact.php">CONTACT</a></li>
      <li><a href="settings.php">SETTINGS</a></li>
    </ul>
  </nav>

  <!-- 🛠 ADMIN SECTION -->
  <section class="admin-wrap">

    <div class="table-head">
      <h1 class="admin-title">ADMIN</h1>
      <div class="pill-user">ADMIN <span class="avatar">👤</span></div>
    </div>

    <!-- Tabs -->
    <div class="role-tabs">
      <button class="tab-btn active" data-role="patient">Patient</button>
      <button class="tab-btn" data-role="dentist">Dentist</button>
    </div>

    <!-- Table -->
    <div class="table-card">
      <div class="table-head">
        <p class="muted">Manage registered users in the system.</p>
        <div class="search-box">
          <input type="text" id="searchInput" placeholder="Search by name or email">
          <button id="searchBtn" class="search-btn">🔍</button>
        </div>
      </div>

      <table class="admin">
        <thead>
          <tr>
            <th style="width:90px;">ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Password</th>
            <th style="width:120px;">Actions</th>
          </tr>
        </thead>
        <tbody id="tableBody"></tbody>
      </table>
    </div>

  </section>
</div>

<script>
/* ===== DATA FROM PHP ===== */
const data = <?php echo json_encode($data, JSON_UNESCAPED_UNICODE); ?>;

let currentRole = 'patient';
let rows = [...data[currentRole]];

const tableBody = document.getElementById('tableBody');
const tabs = document.querySelectorAll('.tab-btn');
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');

function renderTable(list) {
  if (!list.length) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="5" style="text-align:center; padding:20px; font-weight:600;">
          No records found.
        </td>
      </tr>`;
    return;
  }

  tableBody.innerHTML = list.map(u => `
    <tr>
      <td>${u.id}</td>
      <td>${u.name}</td>
      <td>${u.email}</td>
      <td>${u.password}</td>
      <td>
        <button class="icon-btn" onclick="editUser(${u.id})">✎</button>
        <button class="icon-btn" onclick="deleteUser(${u.id})">🗑</button>
      </td>
    </tr>
  `).join('');
}

function switchRole(role) {
  currentRole = role;
  rows = [...data[role]];
  tabs.forEach(t => t.classList.toggle('active', t.dataset.role === role));
  searchInput.value = '';
  renderTable(rows);
}

function doSearch() {
  const q = searchInput.value.toLowerCase().trim();
  const filtered = rows.filter(r =>
    r.name.toLowerCase().includes(q) ||
    r.email.toLowerCase().includes(q)
  );
  renderTable(filtered);
}

async function postForm(url, data) {
  const fd = new FormData();
  Object.entries(data).forEach(([k, v]) => fd.append(k, v));

  const res = await fetch(url, { method: 'POST', body: fd });
  const json = await res.json().catch(() => ({}));

  if (!res.ok || !json.ok) throw new Error(json.error || 'Request failed');
  return json;
}

window.editUser = async function(id) {
  try {
    const u = rows.find(r => String(r.id) === String(id));
    if (!u) return alert('User not found');

    const newName = prompt("Edit Full Name:", u.name || "");
    if (newName === null) return;

    const newEmail = prompt("Edit Email:", u.email || "");
    if (newEmail === null) return;

    await postForm('admin_update_user.php', {
      role: currentRole,
      id: id,
      full_name: newName.trim(),
      email: newEmail.trim()
    });

    u.name = newName.trim();
    u.email = newEmail.trim();

    renderTable(rows);
    alert('Updated successfully ✅');

  } catch (e) {
    alert('Update failed: ' + e.message);
  }
}

window.deleteUser = async function(id) {
  try {
    const ok = confirm(`Confirm delete ${currentRole} ID ${id}?`);
    if (!ok) return;

    await postForm('admin_delete_user.php', {
      role: currentRole,
      id: id
    });

    rows = rows.filter(r => String(r.id) !== String(id));
    data[currentRole] = data[currentRole].filter(r => String(r.id) !== String(id));

    renderTable(rows);
    alert('Deleted successfully ✅');

  } catch (e) {
    alert('Delete failed: ' + e.message);
  }
}


tabs.forEach(tab => {
  tab.addEventListener('click', () => switchRole(tab.dataset.role));
});

searchBtn.addEventListener('click', doSearch);
searchInput.addEventListener('input', doSearch);

renderTable(rows);
</script>

</body>
</html>
