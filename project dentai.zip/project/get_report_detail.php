<?php
session_start();
require 'db.php';

$reportId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$patientId = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM diagnosis_reports WHERE report_id = ? AND patient_id = ?");
$stmt->execute([$reportId, $patientId]);
$report = $stmt->fetch(PDO::FETCH_ASSOC);

if ($report) {
    echo json_encode($report);
} else {
    echo json_encode(['error' => 'Report not found']);
}