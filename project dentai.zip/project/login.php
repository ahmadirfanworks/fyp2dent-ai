<?php
session_start();
require 'db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $role = strtolower($_POST['role'] ?? '');

    if ($email === '' || $password === '' || $role === '') {
        $error = "All fields are required.";
    } else {

        if ($role === 'admin') {
            $table = 'admins';
            $idCol = 'admin_id';
            $passCol = 'password_hash';
            $redirect = 'admindashboard.php';
        } elseif ($role === 'dentist') {
            $table = 'dentists';
            $idCol = 'dentist_id';
            $passCol = 'password_hash';
            $redirect = 'dentist.php';
        } elseif ($role === 'patient') {
            $table = 'patients';
            $idCol = 'patient_id';
            $passCol = 'password_hash';
            $redirect = 'patient.php';
        } else {
            $error = "Invalid role.";
        }

        if ($error === '') {
            // allow login by email OR username
            $stmt = $pdo->prepare("SELECT * FROM $table WHERE email = ? OR username = ? LIMIT 1");
            $stmt->execute([$email, $email]);
            $user = $stmt->fetch();

            if (!$user) {
                $error = "Invalid email or password.";
            } else {
                $dbHash = $user[$passCol] ?? '';

                if (!password_verify($password, $dbHash) && $password !== $dbHash) {
                    $error = "Invalid email or password.";
                } else {
                    $_SESSION['user_id'] = $user[$idCol];
                    $_SESSION['role'] = $role;

                    header("Location: $redirect");
                    exit;
                }
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dent AI | Login</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="login-page">
  <div class="container">

    <!-- 🌿 Navigation -->
    <nav class="nav nav-three">
      <!-- Left: Back -->
      <a href="index.php" class="back">
        <span class="arrow">←</span> Back
      </a>

      <!-- Center: Brand -->
      <a href="index.php" class="brand">
        <span class="logo">🦷</span> DENT AI
      </a>

      <!-- Right: Menu -->
      <ul class="menu">
        <li><a href="index.php">HOME</a></li>
        <li><a href="aboutus.php">ABOUT US</a></li>
        <li><a href="contact.php">CONTACT</a></li>
      </ul>
    </nav>

    <!-- 🔐 Login Form Card -->
    <section class="login-layout">
      <div class="welcome">
        <h2>Welcome Back</h2>
        <h1>Log In to Dent AI</h1>
        <p style="opacity:0.8;">Access your dashboard and continue where you left off.</p>
      </div>

      <form id="loginForm" class="form-card" action="login.php" method="POST">
        <h2>Login</h2>
        <?php if ($error): ?>
  <p style="color:#ff6b6b; font-weight:700; margin:10px 0;">
    <?= htmlspecialchars($error) ?>
  </p>
<?php endif; ?>


        <!-- Email -->
        <label>
          <span class="icon">📧</span>
          <input type="text" name="email" placeholder="Email or Username" required>
        </label>

        <!-- Password -->
        <label>
          <span class="icon">🔒</span>
          <input type="password" name="password" placeholder="Password" required>
        </label>

        <!-- Role Selector -->
        <label>
          <span class="icon">👤</span>
          <select id="role" name="role"  required>
            <option value="">Select Role</option>
            <option value="admin">Admin</option>
            <option value="patient">Patient</option>
            <option value="dentist">Dentist</option>
          </select>
        </label>

        <button type="submit" class="btn-login">Login</button>

        <div class="divider">OR</div>

        <a href="signup.php" class="btn-signup">Create New Account</a>
      </form>
    </section>
  </div>

 

</body>
</html>



