<?php
session_start();

$role = $_SESSION['role'] ?? 'guest';

// link default untuk guest
$patientLink = 'login.php';
$dentistLink = 'login.php';

$patientDisabled = false;
$dentistDisabled = false;

// set dashboard link utk menu
$dashboardLink = 'login.php';

if ($role === 'patient') {
  $dashboardLink = 'patient.php';

  // patient boleh tekan patient sahaja
  $patientLink = 'patient.php';
  $dentistLink = '#';
  $dentistDisabled = true;

} elseif ($role === 'dentist') {
  $dashboardLink = 'dentist.php';

  // dentist boleh tekan dentist sahaja
  $dentistLink = 'dentist.php';
  $patientLink = '#';
  $patientDisabled = true;

} elseif ($role === 'admin') {
  $dashboardLink = 'admindashboard.php';

  // admin optional: dua-dua pergi dashboard admin
  $patientLink = 'admindashboard.php';
  $dentistLink = 'admindashboard.php';
}

?>


<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>DENT AI — Make Your Smile Even Better</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --brand:#6BE267;
      --brand-dark:#4BC247;
      --text:#0B1220;
      --muted:#495057;
      --white:#ffffff;
      --radius:24px;
      --radius-card:28px;
      --shadow-lg:0 20px 50px rgba(0,0,0,.25);
      --shadow-sm:0 8px 24px rgba(0,0,0,.12);
    }
    *{box-sizing:border-box}
    html,body{margin:0;padding:0;}
    body{
      font-family:Poppins,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;
      color:var(--white);
      background-image:url('assets/img/background.png');
      background-size:cover;
      background-repeat:no-repeat;
      background-position:center;
      background-attachment:fixed;
      min-height:100vh;
    }

    .container{max-width:1200px;margin:0 auto;padding:0 24px;}

    /* Nav */
    .nav-wrap{position:sticky;top:16px;z-index:20;}
    .nav{
      display:flex;align-items:center;justify-content:space-between;
      background:rgba(255,255,255,0.95);
      color:#1b1b1b;border-radius:999px;
      padding:10px 16px;
      box-shadow:var(--shadow-sm);
    }
    .brand{display:flex;align-items:center;gap:10px;font-weight:800;letter-spacing:.2px;text-decoration:none;color:#1b1b1b;}
    .brand .logo{width:26px;height:26px;display:grid;place-items:center;border:2px solid #111;border-radius:50%;}
    .menu{display:flex;gap:28px;align-items:center;list-style:none;margin:0;padding:0;}
    .menu a{text-decoration:none;font-weight:700;letter-spacing:.5px;color:#37b24d;opacity:.9;transition:.2s;}
    .menu a:hover{opacity:1;transform:translateY(-1px);}

    /* Hero */
    .hero{
      display:grid;
      grid-template-columns:1.1fr .9fr;
      gap:36px;
      align-items:center;
      padding:56px 0 32px;
    }
    .headline{font-size:clamp(36px,5vw,64px);line-height:1.05;font-weight:800;margin:0;}
    .hero-img{width:100%;height:auto;border-radius:16px;box-shadow:var(--shadow-lg);object-fit:cover;}

    /* Cards */
    .cards{display:grid;grid-template-columns:1fr 1fr;gap:28px;margin:28px 0 72px;}
    .card{
      background:var(--white);
      color:#1b1b1b;
      border-radius:var(--radius-card);
      padding:28px;
      box-shadow:var(--shadow-lg);
    }
    .card-inner{display:grid;grid-template-columns:auto 1fr;gap:18px;align-items:center;}
    .card h3{margin:0;font-size:28px;letter-spacing:.4px;}
    .sub{margin:.25rem 0 1rem;color:#333;font-weight:500;opacity:.85;}
    .cta{
      display:inline-flex;align-items:center;gap:10px;
      background:var(--brand);
      color:#0f2c10;
      border:2px solid #2a6e2a;
      border-radius:999px;
      padding:12px 22px;
      font-weight:800;
      text-decoration:none;
      box-shadow:inset 0 -4px 0 rgba(0,0,0,.1), 0 8px 16px rgba(34,197,94,.35);
      transition:.2s;
    }
    .cta:hover{transform:translateY(-1px);filter:brightness(1.03);}
    .cta.secondary{background:#C2F8C2;}
    .icon{color:#111;display:grid;place-items:center;}
    footer{padding:24px 0 48px;color:rgba(255,255,255,.8);font-size:14px;text-align:center;}

    @media(max-width:980px){
      .hero{grid-template-columns:1fr;gap:18px;}
      .cards{grid-template-columns:1fr;}
      .nav{border-radius:18px;}
    }
  </style>
</head>
<body>
  <div class="container nav-wrap">
    <nav class="nav">
      <a class="brand" href="#">
        <span class="logo" aria-hidden="true">🦷</span>
        <span>DENT AI</span>
      </a>
      <ul class="menu">
        <li><a href="index.php">HOME</a></li>
        <li><a href="aboutus.php">ABOUT US</a></li>
        <li><a href="contact.php">CONTACT</a></li>
       <?php if (!isset($_SESSION['role'])): ?>
  <li><a href="login.php">LOG IN</a></li>
<?php else: ?>
  <li><a href="<?= $dashboardLink ?>">DASHBOARD</a></li>
<?php endif; ?>

      </ul>
    </nav>
  </div>

  <main class="container">
    <section class="hero">
      <div>
        <h1 class="headline">Make Your Smile<br/>Even Better.</h1>
      </div>
      <div>
        <img class="hero-img" src="assets/img/hero.png" alt="Smiling person close-up">
      </div>
    </section>

    <section class="cards">
      <article class="card">
        <div class="card-inner">
          <img src="assets/img/patient_icon.png" alt="Patient" style="height: 60px; border-radius: 50%; background: white; padding: 5px;">
          <div>
            <h3>PATIENT</h3>
            <p class="sub">access and monitor your dental health data now</p>
            <a class="cta <?= $patientDisabled ? 'disabled' : '' ?>"
   href="<?= $patientLink ?>"
   <?= $patientDisabled ? 'onclick="return false;"' : '' ?>>
   View Diagnosis
</a>

          </div>
        </div>
      </article>

      <article class="card">
        <div class="card-inner">
          <img src="assets/img/profile-icon.png" alt="Doctor" style="height: 60px; border-radius: 50%; background: white; padding: 5px;">
          <div>
            <h3>DENTIST</h3>
            <p class="sub">aligning the AI-driven dental diagnostic tool with real-world clinical</p>
            <a class="cta <?= $dentistDisabled ? 'disabled' : '' ?>"
   href="<?= $dentistLink ?>"
   <?= $dentistDisabled ? 'onclick="return false;"' : '' ?>>
   Analyze Now
</a>

          </div>
        </div>
      </article>
    </section>
  </main>

  <footer>© <span id="year"></span> DENT AI · All rights reserved.</footer>

  <script>document.getElementById('year').textContent = new Date().getFullYear();</script>
</body>
</html>
