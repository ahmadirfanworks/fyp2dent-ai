<?php
session_start();
require 'db.php';

// Guard: dentist only
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'dentist') {
  header('Location: login.php');
  exit;
}

$dentistId = (int)$_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM dentists WHERE dentist_id = ? LIMIT 1");
$stmt->execute([$dentistId]);
$d = $stmt->fetch(PDO::FETCH_ASSOC);

$fullName = $d['full_name'] ?? 'Full Name';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$preselect = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dent AI | View History</title>
  <link rel="stylesheet" href="assets/css/style.css" />
  <style>
    .vh-grid{display:grid;grid-template-columns:1fr 1.3fr;gap:18px;margin-top:18px}
    .panel{background:rgba(255,255,255,0.82);backdrop-filter: blur(6px);border-radius:18px;padding:18px;box-shadow:0 8px 22px rgba(0,0,0,.12)}
    .result-list{list-style:none;padding:0;margin:10px 0 0 0;max-height:220px;overflow:auto}
    .result-list li{padding:10px 12px;border-radius:10px;cursor:pointer;border:1px solid rgba(0,0,0,.08);margin-bottom:8px}
    .result-list li:hover{background:rgba(0,0,0,.04)}
    .muted{opacity:.8}
    .btn-row{display:flex;gap:10px;justify-content:flex-end;margin-top:14px;flex-wrap:wrap}
    .smallbtn{padding:10px 14px;border-radius:999px;border:none;cursor:pointer}
    .smallbtn.primary{background:#2f8f2f;color:#fff}
    .smallbtn.ghost{background:transparent;border:1px solid rgba(0,0,0,.15)}
    .hist-table{width:100%;border-collapse:collapse;margin-top:10px}
    .hist-table th,.hist-table td{padding:10px;border-bottom:1px solid rgba(0,0,0,.08);text-align:left;font-size:14px}
    .badge{display:inline-block;padding:4px 10px;border-radius:999px;background:rgba(47,143,47,.12);color:#1f5f1f;font-size:12px}
  </style>
</head>
<body>

<nav class="nav nav-three">
  <a href="index.php" class="brand"><span class="logo">🦷</span> DENT AI</a>
  <ul class="menu">
    <li><a href="dentist.php">DASHBOARD</a></li>
    <li><a href="viewhistory.php" class="active">VIEW HISTORY</a></li>
    <li><a href="profile.php">PROFILE</a></li>
    <li><a href="settings.php">SETTINGS</a></li>
  </ul>
</nav>

<section class="dentist-page container">
  <div class="dentist-card">
    <div class="dentist-left">
      <img src="assets/img/profile-icon.png" alt="Dentist profile" class="profile-icon" />
      <h2><?= h($fullName) ?></h2>
      <p class="role">Dentist</p>
    </div>
    <div class="dentist-right">
      <h3>Patient History</h3>
      <p class="muted">Search patient (name/email), view diagnosis history by year, add treatment, or export history.</p>
    </div>
  </div>

  <div class="vh-grid">
    <div class="panel">
      <h3 style="margin-top:0">Search Patient</h3>
      <input id="patientSearch" type="text" placeholder="Search patient name / email..." style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid rgba(0,0,0,.15)" />
      <div class="muted" style="margin-top:8px;font-size:13px">Tip: type at least 2 characters</div>
      <ul id="searchResults" class="result-list"></ul>
      <div class="btn-row">
        <a class="smallbtn ghost" href="register.php" style="text-decoration:none;color:inherit">Add Patient</a>
      </div>
    </div>

    <div class="panel">
      <h3 style="margin-top:0">Selected Patient</h3>
      <div id="patientInfo" class="muted">No patient selected.</div>
      <div id="patientHistory"></div>
      <div class="btn-row">
        <a id="btnAddTreatment" class="smallbtn primary" href="#" style="text-decoration:none">Add Treatment</a>
        
      </div>
    </div>
  </div>
</section>

<script>
  const searchInput = document.getElementById('patientSearch');
  const resultsEl = document.getElementById('searchResults');
  const patientInfoEl = document.getElementById('patientInfo');
  const patientHistoryEl = document.getElementById('patientHistory');
  const btnAddTreatment = document.getElementById('btnAddTreatment');
 

  let selected = null;

  function setSelected(p){
    selected = p;
    patientInfoEl.innerHTML = `
      <div><strong>${escapeHtml(p.full_name)}</strong> <span class="badge">ID: ${p.patient_id}</span></div>
      <div class="muted" style="margin-top:6px">DOB: ${escapeHtml(p.date_of_birth || '-')}, Contact: ${escapeHtml(p.contact_number || '-')}, Email: ${escapeHtml(p.email || '-')}</div>
    `;
    btnAddTreatment.href = `analyzenow.php?patient_profile_id=${encodeURIComponent(p.patient_id)}`;
   
    loadHistory(p.patient_id);
  }

  async function loadHistory(patientId){
    patientHistoryEl.innerHTML = '<div class="muted" style="margin-top:10px">Loading history...</div>';
    const res = await fetch(`patient_history.php?patient_profile_id=${encodeURIComponent(patientId)}`);
    const data = await res.json();
    if(!res.ok){
      patientHistoryEl.innerHTML = `<div class="muted" style="margin-top:10px">${escapeHtml(data.error || 'Failed to load history')}</div>`;
      return;
    }
    if(!data.reports || data.reports.length === 0){
      patientHistoryEl.innerHTML = `<div class="muted" style="margin-top:10px">No record yet.</div>`;
      return;
    }
    const rows = data.reports.map(r => {
      return `
        <tr>
          <td>${escapeHtml(r.diagnosis_date || r.created_at || '')}</td>
          <td>#${r.report_id}</td>
          <td>${escapeHtml(r.ai_status || '-')}</td>
          <td><a href="diagnosis_result.php?report_id=${encodeURIComponent(r.report_id)}">View</a></td>
        </tr>
      `;
    }).join('');

    patientHistoryEl.innerHTML = `
      <table class="hist-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Report</th>
            <th>AI Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    `;
  }

  let timer = null;
  searchInput.addEventListener('input', () => {
    const q = searchInput.value.trim();
    clearTimeout(timer);
    if(q.length < 2){
      resultsEl.innerHTML = '';
      return;
    }
    timer = setTimeout(() => search(q), 250);
  });

  async function search(q){
    const res = await fetch(`patient_search.php?q=${encodeURIComponent(q)}`);
    const data = await res.json();
    resultsEl.innerHTML = '';
    if(!res.ok){
      resultsEl.innerHTML = `<li class="muted">${escapeHtml(data.error || 'Search error')}</li>`;
      return;
    }
    if(!data.results || data.results.length === 0){
      resultsEl.innerHTML = `<li class="muted">No matching patient.</li>`;
      return;
    }
    data.results.forEach(p => {
      const li = document.createElement('li');
      li.innerHTML = `<strong>${escapeHtml(p.full_name)}</strong><div class="muted" style="font-size:12px;margin-top:2px">${escapeHtml(p.email || '-')}</div>`;
      li.addEventListener('click', () => setSelected(p));
      resultsEl.appendChild(li);
    });
  }

  function escapeHtml(str){
    return String(str ?? '').replace(/[&<>"]|'/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[m]));
  }

  // Optional: preselect from query
  (function(){
    const pre = <?= (int)$preselect ?>;
    if(!pre) return;
    fetch(`patient_history.php?patient_id=${encodeURIComponent(pre)}`)
      .then(r => r.json().then(j => ({ok:r.ok, j})))
      .then(({ok, j}) => {
        if(!ok || !j.patient) return;
        setSelected(j.patient);
      });
  })();
</script>

</body>
</html>
