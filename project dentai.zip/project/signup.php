<?php
require 'db.php';

function backToSignup($msg) {
    echo "<p style='color:red;font-weight:700;'>".htmlspecialchars($msg)."</p>";
    echo "<p><a href='signup.html'>Back to Sign Up</a></p>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: signup.html");
    exit;
}

// Fields from signup.html
$fullname = trim($_POST['fullname'] ?? '');
$email    = trim($_POST['email'] ?? '');
$contact  = trim($_POST['contact_number'] ?? '');
$dob      = trim($_POST['date_of_birth'] ?? ''); // patient only
$pass     = $_POST['password'] ?? '';
$confirm  = $_POST['confirm_password'] ?? '';
$role     = $_POST['role'] ?? '';

if ($fullname === '' || $email === '' || $contact === '' || $pass === '' || $confirm === '' || $role === '') {
    backToSignup("All fields are required.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    backToSignup("Invalid email format.");
}

if ($pass !== $confirm) {
    backToSignup("Passwords do not match.");
}

if (!in_array($role, ['patient', 'dentist'], true)) {
    backToSignup("Invalid role selected.");
}

// Validate DOB only for patient
if ($role === 'patient') {
    if ($dob === '') {
        backToSignup("Date of Birth is required for Patient.");
    }
    // basic date validation YYYY-MM-DD
    $dt = DateTime::createFromFormat('Y-m-d', $dob);
    if (!$dt || $dt->format('Y-m-d') !== $dob) {
        backToSignup("Invalid Date of Birth format.");
    }
}

// Hash password
$password_hash = password_hash($pass, PASSWORD_DEFAULT);

// Generate username from email (simple)
$username = strtolower(preg_replace('/[^a-z0-9]/i', '', explode('@', $email)[0]));
if ($username === '') $username = 'user' . rand(1000, 9999);

try {
    // Check duplicate email across both roles
    $stmt = $pdo->prepare("SELECT 1 FROM patients WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    if ($stmt->fetchColumn()) backToSignup("Email already registered (Patient).");

    $stmt = $pdo->prepare("SELECT 1 FROM dentists WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    if ($stmt->fetchColumn()) backToSignup("Email already registered (Dentist).");

    if ($role === 'patient') {
        // patients table columns:
        // (username, full_name, email, date_of_birth, contact_number, password_hash)
        $stmt = $pdo->prepare("
            INSERT INTO patients (username, full_name, email, date_of_birth, contact_number, password_hash)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$username, $fullname, $email, $dob, $contact, $password_hash]);

    } else { // dentist
        // dentists table columns:
        // (username, full_name, email, contact_number, upload_image, password_hash)
        $stmt = $pdo->prepare("
            INSERT INTO dentists (username, full_name, email, contact_number, upload_image, password_hash)
            VALUES (?, ?, ?, ?, NULL, ?)
        ");
        $stmt->execute([$username, $fullname, $email, $contact, $password_hash]);
    }

    // Success → go to login
    header("Location: signup-success.html");
    exit;

} catch (PDOException $e) {
    backToSignup("Signup failed: " . $e->getMessage());
}
